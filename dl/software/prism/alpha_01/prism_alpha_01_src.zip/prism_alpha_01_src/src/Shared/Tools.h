/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#ifndef INC_TOOLS_H
#define INC_TOOLS_H

#include "plTypes.h"

#include <stdlib.h>
#include <plList.h>
#include <time.h>

#if _WIN32
#include <windows.h>
#endif

//Argument Tools

extern char* cutBeginning(char* source, char split);
extern char* cutEnd(char* source, char* cut);

extern void argDump(int argc, char* argv[]);

extern LIST getStrings(char* fullPath);

#ifdef _WIN32
 #define EXT_EXEC ".exe"
#else
 #define EXT_EXEC ""
#endif

#define EXT_STR ".str"

//Defaults
#define DEF_PORT         "22133"
#define DEF_SCRIPT       "gen/arena_simple.lua"
#define DEF_SERVER       "platypro.net"
#define DEF_GAMEMODE     GAMEMODE_TIMED

#define DEF_GM_TIMED_MAX     90
#define DEF_GM_THRESHOLD_MAX 25

#define DEF_FONT_NORMAL  "Fonts/Roboto.ttf"
#define DEF_FONT_MONO    "Fonts/RobotoMono.ttf"

#define DEF_SETTINGSFILE "prismsettings"EXT_STR

//Tick Tools
#define TICKS_PERSEC 50
#define TICK_LEN 0.02

#if _WIN32
typedef LARGE_INTEGER TICK_OBJ;
#else
typedef struct timespec TICK_OBJ;
#endif

//
// Tick Functions
//

extern int Tick_Get(TICK_OBJ* tick);  //!< Returns tick count since last called

//
// Collision Functions
//

#define COLLISION_BLOCK_SIZE 50
#define OVERLAP_END -67647857

typedef struct CollisionList
{
  LIST* tiles;
  int roomW;
  int roomH;

  int tileW;
  int tileH;
} COLLISIONLIST;

typedef bool (*COLLISIONHANDLE) (IO_RECT rect1, LIST_HEADER type1, IO_RECT rect2, LIST_HEADER type2);

extern bool testRectCollision(IO_RECT* rect1, IO_RECT* rect2);
extern bool testRectRoundCollision(IO_ROUND round, IO_RECT rect);
extern bool testPointInRect(IO_RECT rect, int x, int y);
extern bool testPointInRound(IO_ROUND round, int x, int y);

extern bool HandleCollisionData(IO_RECT zone, LIST_HEADER zonetype, COLLISIONLIST* collisions, COLLISIONHANDLE ch);
extern COLLISIONLIST* GenerateCollsions(LIST roomData, int roomw, int roomh);
extern bool ClearCollisions(COLLISIONLIST** collisions);
extern IO_RECT getPlayerArea(IO_POINT p);
extern bool DetectCollision(IO_RECT p, LIST_HEADER collisionType, COLLISIONLIST* collisions);

//
// Player Functions
//
extern void Team_Player_Add(TEAM* t, PLAYER* p);
extern void Team_Player_Remove(PLAYER* p);

//
// Other Functions
//
extern void updateStamina(PLAYER* p, int amount);
extern IO_POINT updateVelocity(PLAYER* p, int amount, COLLISIONLIST* collisionData);

#endif /*INC_ARGTOOLS_H*/
