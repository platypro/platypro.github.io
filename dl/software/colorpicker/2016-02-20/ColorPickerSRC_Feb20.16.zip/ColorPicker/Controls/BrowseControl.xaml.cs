﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.IO;

namespace ColorPicker.Controls
{
    /// <summary>
    /// Interaction logic for BrowseControl.xaml
    /// </summary>
    public partial class BrowseControl : System.Windows.Controls.UserControl
    {
        public bool folderDialog = false;

        public event TickHandler TextUpdated;
        public EventArgs e = null;
        public delegate void TickHandler(String s, EventArgs e);

        public BrowseControl()
        {
            InitializeComponent();
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            if (folderDialog)
            {
                FolderBrowserDialog dialog = new FolderBrowserDialog();
                dialog.Description = "Select folder to put all output files";
                DialogResult result = dialog.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    ProjDir.Text = dialog.SelectedPath;
                }
            }
            else
            {
                OpenFileDialog dialog = new OpenFileDialog();
                DialogResult result = dialog.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.OK)
                {
                    ProjDir.Text = dialog.FileName;
                }
            }
        }

        private void ProjDir_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                TextUpdated(ProjDir.Text, e);
            }
            catch { }
        }

        public string getPath() { return ProjDir.Text; }
        public void setPath(string path) { ProjDir.Text = path; }
    }
}
