
#ifndef GENERAL_H
#define GENERAL_H

#define PUBLIC
#define PRIVATE static

#define TRUE 1
#define FALSE 0

#define BOOL char
#define FLOAT double

#endif  // GENERAL_H
