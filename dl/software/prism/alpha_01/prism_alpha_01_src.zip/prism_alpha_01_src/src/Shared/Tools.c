/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#include "General.h"
#include "Tools.h"

#include <stdio.h>
#include <plStrings.h>
#include <time.h>
#include <errno.h>
#include <math.h>

#include "plSignals.h"

#ifdef _WIN32
 static LARGE_INTEGER tickTimeScale;
#endif

//
//Argument Functions
//

PRIVATE char* moveEnd(char* source)
{
    char* result = source;
    while(*result != '\0')
        { result++; }  

    return result;
}

PUBLIC char* cutBeginning(char* source, char split)
{
    //First find the end
    char* end = moveEnd(source);

    //Then find the last instance of our character
    while(end >= source && *end != split)
        { end--; }

    //Now return our final value
    return end + 1;
}

PUBLIC char* cutEnd(char* source, char* cut)
{
    //First find the end
    char* end = moveEnd(source);
    //Now find the end of cut,
    //since we need to iterate backwards
    char* cutEnd = moveEnd(cut);
    //Now test and remove characters from source
    while(*cutEnd == *end && end != source && cutEnd >= cut)
    {
        *end = '\0';
        end--;
        cutEnd--;
    }

    return source;
}

LIST getStrings(char* fullPath)
{
    LIST result = NULL;

#ifdef WINDOWS
    fullPath = cutBeginning(fullPath, '\\');
#endif
    char* execName = cutEnd(cutBeginning(fullPath, '/'), EXT_EXEC);
    char* strName  = malloc(25);
    snprintf(strName, 25, "%s%s", execName, EXT_STR);
    result = Strings_Load(strName, false);
    free(strName);
    return result;
}

PUBLIC void argDump(int argc, char* argv[])
{
    int i;
    for(i = 0;i<argc;i++)
    {
        printf("Index:%d; Value:%s\n", i, argv[i]);
    }
}

//
//Tick Functions
//

#if _WIN32
  PRIVATE bool Tick_Update(TICK_OBJ* tickobj)
  {
    if(!tickTimeScale.QuadPart)
      QueryPerformanceFrequency(&tickTimeScale);
    if(!QueryPerformanceCounter(tickobj)) return false;
    return true;
  }

  PRIVATE double getTick(TICK_OBJ tick)
  {
    if(tickTimeScale.QuadPart)
      return (double)tick.QuadPart / (double)tickTimeScale.QuadPart;
    else return 0;
  }

  PRIVATE bool incTick(TICK_OBJ* tick, double amount)
  {
    if(tickTimeScale.QuadPart)
      tick->QuadPart += (amount * tickTimeScale.QuadPart);
    return true;
  }
#else
#define TICKPOW 1000000000
  PRIVATE bool Tick_Update(TICK_OBJ* tickobj)
  {
    bool result = false;
    if(clock_gettime(CLOCK_MONOTONIC, tickobj) != -1)
    {
      result = true;
    }
    return result;
  }

  PRIVATE double getTick(TICK_OBJ tick)
  {
    double result = 0.0;
    result += (double)tick.tv_nsec / TICKPOW;
    result += tick.tv_sec;
    return result;
  }

  PRIVATE bool incTick(TICK_OBJ* tick, double amount)
  {
    int secs = floor(amount);
    tick->tv_sec += secs;
    amount -= secs;
    tick->tv_nsec += amount * TICKPOW;
    
    if(tick->tv_nsec > TICKPOW)
    {
      tick->tv_nsec -= TICKPOW;
      tick->tv_sec++;
    }
    
    return true;
  }
#endif

PUBLIC int Tick_Get(TICK_OBJ* time)
{
  int result = 0;
  TICK_OBJ newTime;
  Tick_Update(&newTime);
  
  result = ((getTick(newTime) - getTick(*time)) / TICK_LEN);

  incTick(time, (double)result * (double)TICK_LEN);
  return result;
}

//
//Collision Functions
//

PRIVATE int findTile(int vector, int blockSize)
{
  return floor((double)vector / (double)blockSize);
}

PRIVATE void findOverlap(int* cache, IO_RECT* rect, int blockSize, int blockW)
{
  int cacheAt = 0;
  //Find Where each point of the rect lies
  int startX, startY, endX, endY, loopX, loopY;
  startX = findTile(rect->x, blockSize);
  startY = findTile(rect->y, blockSize);
  endX   = findTile(rect->x + rect->w, blockSize);
  endY   = findTile(rect->y + rect->h, blockSize);

  //Populate cache
  for(loopX = startX; loopX <= endX; loopX++)
  {
    for(loopY = startY; loopY <= endY; loopY++)
    {
      cache[cacheAt] = (loopY * blockW) + loopX;
      cacheAt ++;
    }
  }

  cache[cacheAt] = OVERLAP_END;

  return;
}

PRIVATE IO_ROUND getRound(IO_RECT rect)
{
  IO_ROUND result;
  result.rx = (rect.w / 2);
  result.ry = (rect.h / 2);
  result.x = rect.x + result.rx;
  result.y = rect.y + result.ry;
  return result;
}

PUBLIC bool testPointInRound(IO_ROUND round, int x, int y)
{
  IO_POINT normalized = {x - round.x,
                         y - round.y};

  return ((((double)(normalized.x * normalized.x)
           / (round.ry * round.rx)) + ((double)(normalized.y * normalized.y) / (round.rx * round.ry)))
      <= 1.0);
}

PUBLIC bool testPointInRect(IO_RECT rect, int x, int y)
{
  return (x > rect.x && x < rect.x + rect.w
       && y > rect.y && y < rect.y + rect.h);
}

PUBLIC bool testRectRoundCollision(IO_ROUND round, IO_RECT rect)
{
  //Test Round collision with Rect
  if( testPointInRect(rect, round.x - round.rx, round.y )  //Left Side
  ||  testPointInRect(rect, round.x + round.rx, round.y )  //Right Side
  ||  testPointInRect(rect, round.x , round.y - round.ry)  //Top Side
  ||  testPointInRect(rect, round.x , round.y + round.ry)) //Bottom Side
  {  return true; }

  //Test Rect Collision with Round
  if( testPointInRound(round, rect.x          , rect.y) //Top Left
  ||  testPointInRound(round, rect.x + rect.w , rect.y) //Top Right
  ||  testPointInRound(round, rect.x , rect.y + rect.h) //Bottom Left
  ||  testPointInRound(round, rect.x + rect.w , rect.y + rect.h))
  {  return true; }
  return false;
}

PUBLIC bool testRectCollision(IO_RECT* rect1, IO_RECT* rect2)
{
  return (rect1->x < rect2->x + rect2->w &&
     rect1->x + rect1->w > rect2->x &&
     rect1->y < rect2->y + rect2->h &&
     rect1->h + rect1->y > rect2->y);
}

PRIVATE bool processRoomData(void* object, unsigned int key, void* data)
{
  COLLISIONLIST* collisionData = (COLLISIONLIST*)data;
  IO_RECT* rect = (IO_RECT*)object;

  int overlapCache[100];
  int* i = overlapCache;

  findOverlap(overlapCache, rect, COLLISION_BLOCK_SIZE, collisionData->tileW);

  while(*i != OVERLAP_END)
  {
    if(*i >= 0 && *i < collisionData->tileW * collisionData->tileH)
      List_Add(&collisionData->tiles[*i], rect, key);
    i++;
  }

  return true;
}

PUBLIC COLLISIONLIST* GenerateCollsions(LIST roomData, int roomw, int roomh)
{
  COLLISIONLIST* result = calloc(1, sizeof(COLLISIONLIST));
  if(result)
  {
    result->tileW = findTile(roomw, COLLISION_BLOCK_SIZE) + 1;
    result->tileH = findTile(roomh, COLLISION_BLOCK_SIZE) + 1;

    result->roomW = roomw;
    result->roomH = roomh;

    //Allocate list list
    result->tiles = calloc(result->tileH * result->tileW, sizeof(LIST));
    if(!result->tiles)
    {
      free(result);
      result = NULL;
    }
    else
    {
      //Fill list list with roomData item clones
      List_Map(&roomData, processRoomData, result);
    }
  }

  return result;
}

PUBLIC bool ClearCollisions(COLLISIONLIST** collisions)
{
  if(*collisions)
  {
    int i;
    for(i = 0; i < (*collisions)->tileH * (*collisions)->tileW; i++)
    {
      List_Clear(&(*collisions)->tiles[i]);
    }

    free((*collisions)->tiles);
    free(*collisions);
    *collisions = NULL;
  }

  return true;
}

//Fine phase collision detection for players
PUBLIC bool Collision_Fine(IO_RECT co1, LIST_HEADER ct1, IO_RECT co2, LIST_HEADER ct2)
{
  //Do special fine colision operations (if needed)
  if(ct1 == HEADER_ROUND && ct2 == HEADER_RECT)
    return testRectRoundCollision(getRound(co1), co2);
  else if(ct1 == HEADER_RECT  && ct2 == HEADER_ROUND)
    return testRectRoundCollision(getRound(co2), co1);

  return true;
}

PUBLIC bool HandleCollisionData(
    IO_RECT zone, LIST_HEADER zonetype, COLLISIONLIST* collisions, COLLISIONHANDLE ch)
{
  bool result = false;
  int overlapCache[50];
  int i;

  //Find collision tiles to process
  findOverlap(overlapCache, &zone, COLLISION_BLOCK_SIZE, collisions->tileW);

  //Find Broad phase collision
  for(i = 0; overlapCache[i]!=OVERLAP_END && i < NUMELEMENTS(overlapCache); i++)
  {
    if(overlapCache[i] >= 0 && overlapCache[i] < collisions->tileW * collisions->tileH)
    {
      IO_RECT* rect;
      LIST list = collisions->tiles[overlapCache[i]];
      if(list)
      {
        //Tile found, look for collision
        foreach(rect, list)
        {
          if(testRectCollision(rect, &zone))
            if( ch(zone, zonetype, *rect, element->objType) )
              result = true;
        }
      }
    }
  }
  return result;
}

PUBLIC bool DetectCollision (IO_RECT p, LIST_HEADER pType, COLLISIONLIST* collisions)
{
  //Test if rect is in room area
  if(p.x < 0 || p.y < 0 || p.w + p.x > collisions->roomW || p.h + p.y > collisions->roomH)
  {
    return true;
  }

  return HandleCollisionData(p, pType, collisions, Collision_Fine);
}

PRIVATE int GetSign(int num)
{
  return (num > 0) - (num < 0);
}

#define VELDETECT(xoff, yoff) \
  !DetectCollision( \
      (IO_RECT){p.x + result.x + (xoff), p.y + result.y + (yoff), p.w, p.h}, \
      pType, collisions)

PUBLIC IO_POINT GetCollision(IO_RECT p, LIST_HEADER pType, COLLISIONLIST* collisions, IO_POINT* velocity)
{
  IO_POINT result = {0, 0};
  int signx = GetSign(velocity->x);
  int signy = GetSign(velocity->y);

  while(((result.x != velocity->x) && velocity->x) || ((result.y != velocity->y) && velocity->y))
  {
    if ((result.x != velocity->x) && velocity->x)
    {
      if(VELDETECT(signx, 0))
      {
        result.x+=signx;
      } else velocity->x = 0;
    }

    if ((result.y != velocity->y) && velocity->y)
    {
      if(VELDETECT(0, signy))
      {
        result.y+=signy;
      } else velocity->y = 0;
    }
  }
  return result;
}

//
// Player Functions
//
PRIVATE PLAYER* Team_Player_Last(PLAYER* p)
{
  while(p->nextTeam != NULL)  { p = p->nextTeam; }
  return p;
}

void Team_Player_Add(TEAM* t, PLAYER* p)
{
  if(!t->firstChild)
    t->firstChild = p;
  else 
  {
    PLAYER* last = Team_Player_Last(t->firstChild);
    last->nextTeam = p;
    p->prevTeam = last;
  }
  
  p->team = t;
  t->childCount++;
  
  return;
}

void Team_Player_Remove(PLAYER* p)
{
  if(p->prevTeam)
    p->prevTeam->nextTeam = p->nextTeam;
  else
    p->team->firstChild = p->nextTeam;
  
  if(p->nextTeam)
    p->nextTeam->prevTeam = p->prevTeam;
  
  p->team->childCount--;
  
  p->team = NULL;
  p->prevTeam = NULL;
  p->nextTeam = NULL;
  
  return;
}

//
// Other Functions
//
IO_RECT getPlayerArea(IO_POINT p)
{
  return (IO_RECT){p.x - PLAYER_RADIUS, p.y - PLAYER_RADIUS,
                   (PLAYER_RADIUS*2), (PLAYER_RADIUS*2)};
}

void updateStamina(PLAYER* p, int amount)
{
  if(p->stamina > 0 && (abs(p->velocity.x) > MOVEMENT_SPEED || abs(p->velocity.y) > MOVEMENT_SPEED))
  {
    p->stamina -= amount;
  }
  
  if(p->stamina < PLAYER_STAMINA_MAX && p->velocity.x == 0 && p->velocity.y == 0)
  {
    p->stamina +=amount;
  }
}

IO_POINT updateVelocity(PLAYER* p, int amount, COLLISIONLIST* collisionData)
{
  IO_POINT newV, collision;

  newV.x = (p->velocity.x * amount);
  newV.y = (p->velocity.y * amount);

  collision = GetCollision(getPlayerArea(p->pos),
      HEADER_ROUND, collisionData, &newV);

  p->pos.x += collision.x;
  p->pos.y += collision.y;
  
  updateStamina(p, amount);
  
  return collision;
}
