/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SRC_SHARED_ERRORS_H_
#define SRC_SHARED_ERRORS_H_

#include <stdio.h>
#include <plList.h>

typedef void (*ERRORCALLBACK)(char* severity, char* message);

typedef struct ErrorManager
{
  FILE* logFile;
  LIST stringFile;
  ERRORCALLBACK userWarnCallback;
} ERRORMANAGER;

#define ERR_MAX_LEN 255

#define ERRSEV_INFO "INFO"
#define ERRSEV_SUCCESS "SUCCESS"
#define ERRSEV_USERWARN "USERWARN"
#define ERRSEV_WARN "WARNING"
#define ERRSEV_IGNORE "ERROR"
#define ERRSEV_FATAL "FATAL"

extern ERRORMANAGER* Errors_Init(char* logPath, LIST stringFile);
extern void Errors_Cleanup(ERRORMANAGER** errors);

extern void Errors_SetWarnCallback(ERRORMANAGER* errors, ERRORCALLBACK callback);

extern void Errors_Throw(ERRORMANAGER* errors, char* severity, char* message);
extern void Errors_ThrowFormat(ERRORMANAGER* errors, char* severity,
    char* emesgID, const char* custom);

#endif /* SRC_SHARED_ERRORS_H_ */
