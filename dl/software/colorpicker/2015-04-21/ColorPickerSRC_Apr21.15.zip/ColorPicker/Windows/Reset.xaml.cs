/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.Windows;

namespace ColorPicker.Windows
{
    /// <summary>
    /// Interaction logic for Reset.xaml
    /// </summary>
    public partial class Reset : Window
    {
        public Boolean[] resets;

        public Reset()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            resets = new Boolean[3];
            resets[0] = this.Red.IsChecked.Value;
            resets[1] = this.Green.IsChecked.Value;
            resets[2] = this.Blue.IsChecked.Value;

            DialogResult = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GlassHelper.ExtendGlassBottom(this, 40);
        }
    }
}
