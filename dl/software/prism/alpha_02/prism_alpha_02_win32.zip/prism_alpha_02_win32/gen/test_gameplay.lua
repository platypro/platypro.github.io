function Prism_Gen()
  --Set room size
  prZone(200,200)
  
  --Set up both test flags
  prFlag(0  , 0  , 50, 50)
  prFlag(150, 0  , 50, 50)
end
