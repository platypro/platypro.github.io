﻿/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.Windows.Controls;

namespace ColorPicker.Controls
{
    /// <summary>
    /// Interaction logic for NumUpDown.xaml
    /// </summary>
    public partial class NumUpDown : UserControl
    {
        private double lowerBound = 0;
        private double safe = 0;
        private double upperBound = 1;
        private double increment = 0.1;
        private int decimals = 1;
        
        public NumUpDown()
        {
            InitializeComponent();
        }

        /// <summary>
        /// sets the maximum and minimum boundaries of the number picker
        /// </summary>
        /// <param name="lower">Lower bound to set</param>
        /// <param name="upper">Upper bound to set</param>
        public void setNumBounds(double lower, double upper, double inc, int dec)
        {
            lowerBound = lower; upperBound = upper; increment = inc; decimals = dec;
            NumBounds.Content = "(" + lowerBound + "," + upperBound + ")";
        }

        public double getValue() { return safe; }
        public void setValue(double value) { Insert.Text = value.ToString(); }

        private void Down_Click(object sender, System.Windows.RoutedEventArgs e)
        { Insert.Text = (safe - increment).ToString(); }

        private void Up_Click(object sender, System.Windows.RoutedEventArgs e)
        { Insert.Text = (safe + increment).ToString(); }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(Insert.Text))
                safe = 0;
            else
            {
                double num = 0;
                bool success = double.TryParse(Insert.Text, out num);
                if (success & num >= lowerBound & num <= upperBound)
                {
                    Insert.Text.Trim();
                    if (!Insert.Text.EndsWith("."))
                    {
                        Insert.Text = Math.Round(num, decimals).ToString();
                    }
                    safe = Convert.ToDouble(Insert.Text);
                }
                else
                {
                    Insert.Text = safe.ToString();
                }
                Insert.SelectionStart = Insert.Text.Length;
            }
        }

    }
}
