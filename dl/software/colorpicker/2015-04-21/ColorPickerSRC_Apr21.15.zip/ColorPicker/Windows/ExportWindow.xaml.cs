﻿/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.IO;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using System.Diagnostics;
using ColorPicker.Controls;
using System.Collections.Specialized;

namespace ColorPicker.Windows
{
    /// <summary>
    /// Interaction logic for ExportWindow.xaml
    /// </summary>
    public partial class ExportWindow : Window
    {
        String appdir = Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath);

        private int stepAt = 0;

        public ExportWindow()
        {
            InitializeComponent();
        }

        private Boolean checkFiles(string path, string[] filenames)
        {
            bool success = true;
            foreach (string file in filenames)
            {
                if(File.Exists(path + file))
                {
                    success = false;
                }
            }

            if (success == false)
            {
                MessageBoxResult prompt =
                    System.Windows.MessageBox.Show("There are files in this directory that will be overwritten by the program, overwrite?",
                    "File Exists",
                    MessageBoxButton.YesNo);
                if (prompt == MessageBoxResult.Yes)
                {
                    success = true;
                }
            }

            return success;
        }

        private void saveConfig(string configFile, string name, string dir)
        {
            StreamWriter sw = new StreamWriter(configFile);
            sw.WriteLine(name);
            sw.WriteLine(dir);
            sw.WriteLine("palette");
            sw.WriteLine(BlaFudge.getValue());
            sw.WriteLine(ColFudge.getValue());
            sw.WriteLine(Gain.getValue());
            sw.WriteLine(Offset.getValue());
            sw.WriteLine(Invert.IsChecked);
            sw.Close();
        }

        private Boolean copyFile(string filepath, string topath)
        {
            if (filepath != topath)
            {
                if (File.Exists(topath))
                {
                    MessageBoxResult prompt =
                    System.Windows.MessageBox.Show("File " + topath + " Will be overwritten by the program. Continue with this file?",
                    "File Exists",
                    MessageBoxButton.YesNo);
                    if (prompt == MessageBoxResult.Yes)
                    {
                        File.Delete(topath);
                    }
                    else { return false; }
                }
                File.Copy(filepath, topath);
            }
            return true;
        }

        private void doExport()
        {
            try
            {
                string name = ProjName.Text;
                string path = ProjDir.getPath();
                string[] filenames = {"conf.cfg", name + ".html", name + ".txt", "palette.txt",
                                         name + "-R.wav", name + "-G.wav", name + "-B.wav"};
                if (checkFiles(path, filenames))
                {
                    if (PalLoc.getPath() != "" & PalLoc.getPath() != "automatic")
                        copyFile(PalLoc.getPath(), path + filenames[3]);
                    else
                        copyFile(Path.GetTempPath() + filenames[3], path + filenames[3]);
                    copyFile(CLoc.getPath(), path + name + "-C.wav");
                    copyFile(ILoc.getPath(), path + name + "-I.wav");
                    copyFile(XLoc.getPath(), path + name + "-X.wav");
                    copyFile(YLoc.getPath(), path + name + "-Y.wav");

                    saveConfig(path + filenames[0], ProjName.Text, path);

                    string strCmdText;
                    strCmdText = "/C " + appdir + "\\CIRGB.exe " + path + "conf";
                    Debug.Print(strCmdText);
                    Process.Start("CMD.exe", strCmdText);

                    Properties.Settings.Default.LastExportLocation = path;
                    Properties.Settings.Default.LastProjectName = name;
                    Properties.Settings.Default.LastGain = Gain.getValue();
                    Properties.Settings.Default.LastOffset = Offset.getValue();
                    Properties.Settings.Default.LastColor = ColFudge.getValue();
                    Properties.Settings.Default.LastBlanking = BlaFudge.getValue();

                    this.DialogResult = true;
                }
            }
            catch (UnauthorizedAccessException)
            {
                System.Windows.MessageBox.Show("Error! You don't have write access to your project folder.");
            }
        }

        private void resetStep()
        {
            FilePanel.Visibility = System.Windows.Visibility.Hidden;
            PropertiesPanel.Visibility = System.Windows.Visibility.Hidden;

            NextStep.Content = "Next";
            UpdateFields();
        }

        private void setStep(int step)
        {
            resetStep();
            if (step > 0) { PrevStep.IsEnabled = true; }
            if(step == 0)
            {
                PrevStep.IsEnabled = false;
                PropertiesPanel.Visibility = System.Windows.Visibility.Visible;
                NextStep.Content = "Next";
            }
            else if (step == 1)
            {
                PalLoc.setPath("automatic");
                NextStep.Content = "Export";
                if (!ProjDir.getPath().EndsWith("\\"))
                {
                    ProjDir.setPath(ProjDir.getPath() + "\\");
                }
                FilePanel.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                doExport();
            }
        }

        private void OK_Button_Click(object sender, RoutedEventArgs e)
        {
            stepAt++;
            setStep(stepAt);
        }
        
        private void Prev_Button_Click(object sender, RoutedEventArgs e)
        {
            stepAt--;
            setStep(stepAt);
        }

        private void SetFields()
        {
            ProjDir.setPath(Properties.Settings.Default.LastExportLocation);
            ProjName.Text = Properties.Settings.Default.LastProjectName;

            Gain.setValue(Properties.Settings.Default.LastGain);
            Offset.setValue(Properties.Settings.Default.LastOffset);
            ColFudge.setValue(Properties.Settings.Default.LastColor);
            BlaFudge.setValue(Properties.Settings.Default.LastBlanking);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GlassHelper.ExtendGlassBottom(this, 40);
            if(!File.Exists(appdir + "\\CIRGB.exe"))
            {
                System.Windows.MessageBox.Show("Error! CIRGB.exe can not be found in ColorPicker's directory, please move it to the right place, or redownload.");
                this.DialogResult = false;
            }

            BlaFudge.setNumBounds(-1, 1, 0.01, 2);
            ColFudge.setNumBounds(-1, 1, 0.01, 2);
            Gain.setNumBounds    (0 , 1, 0.01, 2);
            Offset.setNumBounds  (-10000, 10000, 1, 0);

            ProjDir.folderDialog = true;

            SetFields();
            UpdateFields();
        }

        private Boolean CheckPath(String path, Boolean isFile)
        {
            if (isFile) { return (File.Exists(path)      || path == "current"); }
            else        { return (Directory.Exists(path) || path == "current"); }
        }

        private System.Windows.Controls.Label updateLabel(Boolean isValid, System.Windows.Controls.Label update, ref Boolean success)
        {
            if (isValid)
            {
                update.Foreground = Brushes.Black;
            }
            else
            {
                update.Foreground = Brushes.Red;
                success = false;
            }
            return update;
        }

        private void UpdateFields()
        {
            Boolean success = true;
            if (stepAt == 0)
            {
                NameLab = updateLabel(ProjName.Text != "", NameLab, ref success);
                DirLab = updateLabel(CheckPath(ProjDir.getPath(), false), DirLab, ref success);
            }
            else
            {
                CLab = updateLabel(CheckPath(CLoc.getPath(), true), CLab, ref success);
                ILab = updateLabel(CheckPath(ILoc.getPath(), true), ILab, ref success);
                XLab = updateLabel(CheckPath(XLoc.getPath(), true), XLab, ref success);
                YLab = updateLabel(CheckPath(YLoc.getPath(), true), YLab, ref success);
            }

            NextStep.IsEnabled = success;
        }

        private void updatePaths()
        {
            CLoc.setPath(""); ILoc.setPath(""); XLoc.setPath(""); YLoc.setPath("");
            if (CheckPath(ProjDir.getPath(), false))
            {
                String wavdir = ProjDir.getPath() + ProjName.Text;
                CLoc = setPath(CLoc, wavdir + "-C.wav");
                ILoc = setPath(ILoc, wavdir + "-I.wav");
                XLoc = setPath(XLoc, wavdir + "-X.wav");
                YLoc = setPath(YLoc, wavdir + "-Y.wav");
            }
            UpdateFields();
        }

        private void ProjDir_TextUpdated(string s, EventArgs e)
        {
            ProjDir.setPath(s.Replace(" ", string.Empty));
            updatePaths();
        }

        private BrowseControl setPath(BrowseControl browser, String path)
        {
            if (CheckPath(path, true))
            {
                browser.setPath(path);
            }
            return browser;
        }

        private void ProjName_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            updatePaths();
        }

        private void Browse_TextUpdated(string s, EventArgs e)
        {
            UpdateFields();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult prompt =
                System.Windows.MessageBox.Show("This will reset all fields. Would you like to continue?",
                "File Exists",
                MessageBoxButton.YesNo);
            if (prompt == MessageBoxResult.Yes)
            {
                Properties.Settings.Default.Reset();
                SetFields();
            }
        }
    }
}