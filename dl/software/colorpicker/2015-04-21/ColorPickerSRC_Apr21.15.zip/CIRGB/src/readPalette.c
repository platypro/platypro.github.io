#include <stdint.h>
#include <stdio.h>
#include <ctype.h>

#define int64  int64_t

#include "General.h"
#include "readPalette.h"


PRIVATE int palette_array[3][MAX_PALETTE_S][2];

PRIVATE RGB ftable[FTABLE_SIZE];

#define SCALE_VAL(x) x = x * (1.0/MAX_VAL_S)

PRIVATE void scaleTable( void )
{
	int i;
	for (i=0; i < FTABLE_SIZE; ++i)
	{
		SCALE_VAL(ftable[i].Red);
		SCALE_VAL(ftable[i].Green);
		SCALE_VAL(ftable[i].Blue);
	}
}

PRIVATE void buildTable( void )
{
	int i;
	for (i=0; i < 3; ++i)  // for each color.
	{
		int segs = palette_array[i][0][0];		// Total number segments.
		int s = 1;	// Current segment offset.
		int x = 0;	// index for ftable.
		int c;		// steps in this segment.
		FLOAT v;	// Current value.
		FLOAT st;	// Current step value.

		while (s <= segs)
		{
			v  =  palette_array[i][s][1];
			c  = (palette_array[i][s+1][0]-palette_array[i][s][0]);
			st = (palette_array[i][s+1][1]-v) / (c-1);

			while (c > 0)
			{
				switch (i)
				{
					case 0: { ftable[x].Red   = v; break; }
					case 1: { ftable[x].Green = v; break; }
					case 2: { ftable[x].Blue  = v; break; }
				}

				v += st;
				--c;
				if (++x == FTABLE_SIZE) break;
			}

			++s;
			if (x == FTABLE_SIZE) break;
		}
	}
}


PUBLIC BOOL readPalette( char *fname )
{
	FILE *palette_fd = fopen(fname, "rb");

    palette_array[0][0][0] = 0;
    palette_array[1][0][0] = 0;
    palette_array[2][0][0] = 0;

	if (palette_fd)
	{
	    int *ndx = &palette_array[0][0][0];
		int color = 0;

		while (!feof(palette_fd))
		{
			char buf[100];

			if (fgets(buf, sizeof(buf), palette_fd))
			{
				if (*buf == '_')
				{
					switch (*(buf+1))
					{
						case 'R': { color = 0; break; }
						case 'G': { color = 1; break; }
						case 'B': { color = 2; break; }
					}
					ndx = &palette_array[color][0][0]; 
					*ndx = 1; 
				}
				else if (isdigit((int)*buf))
				{
					int a,b;
					int n = sscanf(buf, "%d|%d|", &a, &b);

					if (n == 2)
					{
//						printf("c %d, n %d, a %d, b %d\n", color, *ndx, a, b);

						palette_array[color][*ndx][0] = a;
						palette_array[color][*ndx][1] = b;

						if (*ndx < MAX_PALETTE_S) { ++(*ndx); }
					}
					else
					{ 
						printf("scanf %d fail!\n", n);
						fclose(palette_fd);
						return FALSE;
					}
				}
			}
		}

		fclose(palette_fd);
	}

	buildTable();		// Read fgile and build RGB lookup table.
	scaleTable();
	return TRUE;
}



PUBLIC void scaleRGB( RGB *dest, FLOAT scale )
{
	dest->Red   *= scale;
	dest->Green *= scale;
	dest->Blue  *= scale;
}

PUBLIC void setRGB( RGB *dest, RGB *source )
{
	dest->Red   = source->Red;
	dest->Green = source->Green;
	dest->Blue  = source->Blue;
}

PUBLIC void interpRGB( RGB *dest, RGB *sourceL, RGB *sourceH, FLOAT f )
{
	dest->Red   = ((sourceH->Red   - sourceL->Red  ) * f) + sourceL->Red;
	dest->Green = ((sourceH->Green - sourceL->Green) * f) + sourceL->Green;
	dest->Blue  = ((sourceH->Blue  - sourceL->Blue ) * f) + sourceL->Blue;
}

PUBLIC void lookupRGB(FLOAT f, RGB *rgb)
{
	     if (f == 0) { setRGB(rgb, ftable); }
	else if (f == 1) { setRGB(rgb, &ftable[FTABLE_SIZE-1]); }
	else
	{
		FLOAT r = f * (FLOAT)(MAX_PALETTE_S-1.0);
		int idx = (int)r;
		RGB *r1 = &ftable[idx];
		RGB *r2 = r1 + 1;  //&ftable[idx+1];

		r -= idx;

		interpRGB(rgb, r1, r2, r);
	}
}


PUBLIC void dumpTable( char *fname  )
{
	FILE *fd = fopen(fname, "w");

	if (fd)
	{
		int i;
		for (i=0; i < FTABLE_SIZE; ++i)
		{
			fprintf(fd, "%d\t%f %f %f\n", 
				i, ftable[i].Red, ftable[i].Green, ftable[i].Blue);
		}
		fclose(fd);
	}
	else { printf("Can't open \"%s\"\n", fname); }
}


#define HTML_PREAMBLE "\
<html xmlns=\"http://www.w3.org/1999/xhtml\">\
<head><title>Html Color Codes</title></head>\
<body><style type=\"text/css\">.tg  {border-collapse:collapse;border-spacing:0;}.tg td{font-family:Arial, sans-serif;font-size:28px;padding:400px 0px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;}tg th{font-family:Arial, sans-serif;font-size:28px;font-weight:normal;padding:40px 0px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;}.tg .tg-glis{font-size:20px}</style>\
<table class=\"tg\" id=\"colorchart\" style=\"width:100%%\"><tr>"

#define HTML_BODY "<td bgColor=\"#%2.2X%2.2X%2.2X\"></td>"

#define HTML_POSTAMBLE "</tr></table></body></html>"

#define HTML_VAL(v) (0xFF & (int)((v) * (FLOAT)MAX_VAL_S))

PUBLIC void dumpHtml( char *fname )
{
	FILE *fd = fopen(fname, "w");

	if (fd)
	{
		int i;

		fprintf(fd, HTML_PREAMBLE);

		for (i=0; i < FTABLE_SIZE; ++i)
		{
			fprintf(fd, HTML_BODY, 
				HTML_VAL(ftable[i].Red),
				HTML_VAL(ftable[i].Green), 
				HTML_VAL(ftable[i].Blue)
			);
		}

		fprintf(fd, HTML_POSTAMBLE);

		fclose(fd);
	}
	else { printf("Can't open \"%s\"\n", fname); }
}


void dumpTableFine( char *fname, int steps )
{
	FILE *fd = fopen(fname, "w");

	if (fd)
	{
		FLOAT f;
		for (f=0; f < 1.0; f += (1.0/steps))
		{
			RGB rgb;

			lookupRGB(f, &rgb);

			fprintf(fd, "%f\t%f %f %f\n", 
				f, rgb.Red, rgb.Green, rgb.Blue);
		}
		fclose(fd);
	}
	else { printf("Can't open \"%s\"\n", fname); }
}


PUBLIC void dumpHtmlFine( char *fname, int steps )
{
	FILE *fd = fopen(fname, "w");

	if (fd)
	{
		FLOAT f;

		fprintf(fd, HTML_PREAMBLE);

		for (f=0; f < 1.0; f += (1.0/steps))
		{
			RGB rgb;

			lookupRGB(f, &rgb);

			fprintf(fd, HTML_BODY, 
				HTML_VAL(rgb.Red),
				HTML_VAL(rgb.Green), 
				HTML_VAL(rgb.Blue)
			);
		}

		fprintf(fd, HTML_POSTAMBLE);

		fclose(fd);
	}
	else { printf("Can't open \"%s\"\n", fname); }
}

// EndFile: readPalette.c
