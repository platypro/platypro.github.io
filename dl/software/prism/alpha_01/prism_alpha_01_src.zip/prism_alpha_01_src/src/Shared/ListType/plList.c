/* 
 * Aeden McClain (c) 2016
 * web:   https://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#include "General.h"
#include "plList.h"

#include <string.h>
#include <stdlib.h>

PRIVATE bool List_DefaultClean(void* object, LISTTYPE key, void* data)
{
    free(object);
    return true;
}

PUBLIC LIST List_FindLast(LIST origin)
{
	//Initialise result to first element
    //(Argument passed in)
    LIST result = origin;

	if(origin)
	{
		//Increment the result until it is
		//the second-last. Hence testing
		//result->sibling
		while(result->sibling)
			result = result->sibling;
	}

    //Finally, return the result
    return result;
}

PRIVATE bool List_Reg(LIST* list, LIST add)
{
    if(list && *list)
    {
        LIST lastElement = List_FindLast(*list);
        lastElement->sibling = add;
        add->elder = *list;
    } 
    else
    { 
        add->elder = add;
        *list      = add; 
    }
    add->sibling = NULL;

    return true;
}

//If list is null, create a new list
PUBLIC bool List_Add(LIST* list, void* object, LISTTYPE header)
{
    LIST result = calloc(1, sizeof(LISTITEM));
    if(result)
    {
        result->objType = header;
        result->object  = object;
        List_Reg(list, result);
    }
    *list = result->elder;
    return true;
}

PUBLIC void* List_Add_Alloc(LIST* list, size_t size, LISTTYPE header)
{
    void* object = calloc(1, size);
    LIST newlist = calloc(1, sizeof(LISTITEM));
    if(object && newlist)
    {
      newlist->objType = header;
      newlist->object  = object;
      List_Reg(list, newlist);
    }
    return object;
}

PRIVATE bool List_SetElder(LIST list, LIST newelder)
{
	LIST i;
    for(i = list;i; i = i->sibling)
        i->elder = newelder;

    return true;
}

PUBLIC LIST List_Promote(LIST* list, void* object, LISTTYPE header)
{
  LIST find;
  LIST last = *list;
  LIST c = *list;
  
  //Find list item
  while(c->object != object || c->objType != header)
  {
    last = c;
    c = c->sibling;
    if(!c) return NULL;
  }
  
  //Take note of the found list item
  find = c;
  
  //If object is not at the end of the list
  if (c->sibling)
  {
    //Remove list entry from list
    if (last != c)
    {
      last->sibling = c->sibling;
    }
    else
    {
      List_SetElder(*list, find->sibling);
      *list = find->sibling;
    }
    
    //Find end of list
    while (c->sibling)
    {
      c = c->sibling;
    }
    
    //Insert found entry back into list
    c->sibling = find;
    find->sibling = NULL;
  }
  
  return find;
}

PUBLIC bool List_Sort(LIST* list, LCOMPAR compar)
{
  int sorted   = true;

  do
  {
    sorted = true;
    LIST listptr = *list;
    LIST last    = NULL;

    while(listptr && listptr->sibling)
    {
      int diff = compar(listptr->object, listptr->sibling->object);

      if(diff < 0)
      {
        LIST sibl = listptr->sibling;
        //Swap
        if(!last) 
          {
            List_SetElder(*list, sibl);
            *list = sibl;
          }
        else      last->sibling = sibl;

        listptr->sibling = sibl->sibling;
        sibl->sibling = listptr;
        sorted = false;
      }

      last = listptr;
      listptr = listptr->sibling;
    }
  } while(!sorted);
  
  return sorted;
}

PRIVATE LIST List_InternalRemove(LIST* list, LIST test)
{
  LIST result = *list;
  LIST i;
  //Then remove the element...
  if(test == (*list)->elder)
  {
    result = test->sibling;
    List_SetElder(test, test->sibling);
  }
  else 
  {
    i = test->elder;

    while(i)
    {
      if(i->sibling == test)
      {
        i->sibling = test->sibling;
        break;
      }
      i = i->sibling;
    }
  }
  if(test->elder == test && test->sibling == NULL)
    { *list = NULL; }

  memset(test, 0, sizeof(LISTITEM));
  free(test);
  
  return result;
}

PUBLIC bool List_RemoveEntry(LIST* list, LIST entry)
{
  *list = List_InternalRemove(list, entry);
  return true;
}

PUBLIC bool List_Remove(LIST* list, void* object)
{
    bool success = false;
    LIST result = NULL;
    if(*list)
    {
        result = (*list)->elder;
        //Firstly, find our list element
        LIST test = *list;
        while(test)
        {
            if(test->object == object) break;
            test = test->sibling;
        }
        if(test)
        {
          result = List_InternalRemove(list, test);
          success = true;
        }
        else { success = false;}
    }
    *list=result;
    return success;
}

PUBLIC int List_Count(LIST* list)
{
    int count = 0;
    LIST current;
    for(current = *list; current; current=current->sibling)
    {
        count++;
    }
    return count;
}

PUBLIC bool List_Map(LIST* list, LISTMOD map, void* data)
{
  bool result = true;
  if(*list && map)
  {
    LIST current, next;
    for(current = *list; current; current=next)
    {
      next = current->sibling;
      result = map(current->object, current->objType, data);
      if (!result) break;
    }
  }
  return result;
}

PUBLIC bool List_Merge(LIST* append, LIST* in)
{
	if(!(*append))
	{
		*append = *in;
	}
	else
	{
		LIST lastlist = List_FindLast(*append);
		lastlist->sibling = *in;
		List_SetElder(*in, (*append)->elder);
	}
	return true;
}

PUBLIC bool List_Clear(LIST* list)
{
    bool result = true;

    if(*list)
    while(*list)
    {
        result = List_Remove(list, (*list)->object);
    }

    return result;
}

PUBLIC bool List_Purge(LIST* list, LISTMOD destroy)
{
    bool result = true;
    if(destroy) result = List_Map(list, destroy, NULL);
    else        result = List_Map(list, List_DefaultClean, NULL);
    result = List_Clear(list);
    return result;
}

int List_FindIndex(LIST* list, void* object)
{
    int result = 0;
    LIST at = *list;
    
    while(at)
    {
        if(at->object == object)
        {
            return result;
        }
        result ++;
    }

    return -1;
}

PUBLIC void* List_GetI(LIST* list, int index)
{
    void* result = NULL;

    LIST at = *list;
    int i = 0;
    while(at)
    {
        if(i == index) 
        { 
            result = at->object; 
            break; 
        }
        at=at->sibling; i++;
    }

    return result;
}

PRIVATE LIST List_GetO(LIST* list, void* object)
{
    LIST result = *list;
    while(result)
    {
        if(result->object == object) break;
        result=result->sibling;
    }
    return result;
}

PRIVATE void** List_FindQ(LIST* list, LISTTYPE query, void* header)
{
    void** result = NULL;

    if(list){
        LIST at;
        if(header) at = List_GetO(list, header)->sibling;
        else       at = *list;

        while(at)
        {
            if(at->objType == query) 
            {
                result = &at->object;
                break;
            }
            at=at->sibling;
        }
    }

    return result;
}

PUBLIC void* List_GetQ(LIST* list, LISTTYPE query, void* header)
{
    void** result = List_FindQ(list, query, header);
    if(result)
    {
        return *result;
    } else return NULL;
}

PUBLIC bool List_Reset(LIST* list, LISTTYPE query, void* object, void* header)
{
    void** listItem = List_FindQ(list, query, header);
    *listItem = object;
    return true;
}
