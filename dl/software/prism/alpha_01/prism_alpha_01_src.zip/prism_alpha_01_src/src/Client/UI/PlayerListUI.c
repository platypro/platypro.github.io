/*
 * Aeden McClain (c) 2017
 * web:   https://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "General.h"
#include "PlayerListUI.h"

#include "Prism.h"
#include "LibHelper.h"
#include "plStrings.h"

PRIVATE void drawPlayerName(LIBSTATE* ls, char* name, IO_RECT draw, int flags)
{
  int rowheight = draw.h / PLAYERLIST_DIVISIONS;
  IO_POINT pname =
  {
    draw.x,
    draw.y + (rowheight / 2)
  };
  
  if(flags & PLUI_PLAYER_READY)
    pname.x += rowheight;
  
  if(pname.x == draw.x) pname.x+=LIST_PADDING;

  
  Draw_Color(ls, COLOR_BLACK);
  
  nvgBeginPath(ls->draw);
  nvgTextAlign(ls->draw, NVG_ALIGN_LEFT|NVG_ALIGN_MIDDLE);
  nvgText(ls->draw, pname.x, pname.y, name, NULL);
}

PUBLIC void PlayerListUI_Draw(LIBSTATE* ls, EVENTSTATE* e, IO_RECT draw, SERVERCONNECTION* connection, int flags)
{
  PLAYER* localPlayer = &Server_GetActivePlayer(connection)->player;
  char buffer[15]; // Buffer for team label/player numbering
  int rowheight = draw.h / PLAYERLIST_DIVISIONS;
  int count = 0; //Prevent lock-ups
  
  PLAYER* p;
  TEAM* t;
  foreach(t, connection->teams)
  {
    count ++;
    if(t->id > 0)
    {      
      if(flags & PLUI_TEAM_SHOW) // Team name is shown
      {
        nvgFontSize(ls->draw, rowheight - PLAYERENTRY_SPACING);
        if(e && flags & PLUI_TEAM_ALLOWCHANGE)
        {
        if(localPlayer->team != t) // Team changes allowed
        {
          IO_RECT item = {draw.x, draw.y, draw.w, rowheight};
          //Sense clicking
          if(testPointInRect(item, e->x, e->y))
          {
            Draw_Color(ls, COLOR_WHITE);
            Draw_Rect(ls, item);

            if(!e->pressed && e->lastpressed)
            {
              //Change team
              Team_Player_Remove(localPlayer);
              Team_Player_Add(t, localPlayer);
              connection->update_team = true;
            }
          }
          
          IO_COLOR joincolor = COLOR_GREEN;
          
          int arrowbackx = draw.x + 3*(rowheight / 5);
          int frontx     = draw.x + rowheight - 4;
          int arrowpointy = draw.y + (rowheight / 2);
          
          //Draw join button
          Draw_Color(ls, joincolor);
          nvgBeginPath(ls->draw);
          nvgMoveTo(ls->draw, draw.x + 2, arrowpointy);
          nvgLineTo(ls->draw, frontx - 5, arrowpointy);
          nvgLineTo(ls->draw, arrowbackx, arrowpointy - 10);
          nvgLineTo(ls->draw, arrowbackx, arrowpointy + 10);
          nvgLineTo(ls->draw, frontx - 5, arrowpointy);
          nvgFill(ls->draw);
          
          nvgStrokeColor(ls->draw, nvgRGB(joincolor.r,joincolor.g,joincolor.b));
          nvgBeginPath(ls->draw);
          nvgMoveTo(ls->draw, arrowbackx, draw.y + 4);
          nvgLineTo(ls->draw, frontx, draw.y + 4);
          nvgLineTo(ls->draw, frontx, draw.y + rowheight - 4);
          nvgLineTo(ls->draw, arrowbackx, draw.y + rowheight - 4);
          nvgStroke(ls->draw);
        }
        else // Player already part of team
        {
          int arrowpointx = draw.x + (rowheight / 2);
          int arrowbacky = draw.y + 3*(rowheight / 5);
          int fronty     = draw.y + rowheight - 4;
          
          Draw_Color(ls, COLOR_BLACK);
          nvgBeginPath(ls->draw);
          nvgMoveTo(ls->draw, arrowpointx, draw.y + 2);
          nvgLineTo(ls->draw, arrowpointx, fronty - 5);
          nvgLineTo(ls->draw, arrowpointx - 10, arrowbacky);
          nvgLineTo(ls->draw, arrowpointx + 10, arrowbacky);
          nvgLineTo(ls->draw, arrowpointx, fronty - 5);
          nvgFill(ls->draw);
        }
        }
        else if(localPlayer->team == t)
        {
          Draw_Color(ls, COLOR_BLACK);
          nvgBeginPath(ls->draw);
          nvgMoveTo(ls->draw, draw.x, draw.y);
          nvgLineTo(ls->draw, draw.x, draw.y + rowheight);
          nvgLineTo(ls->draw, draw.x + rowheight - 5, draw.y + (rowheight / 2));
          nvgFill(ls->draw);
          
        }
        
        Draw_Color(ls, COLOR_BLACK);
               
        if(flags & PLUI_TEAM_SCORE)
        {
          snprintf(buffer, 15, "%d", t->teamscore);
          nvgBeginPath(ls->draw);
          nvgTextAlign(ls->draw, NVG_ALIGN_CENTER|NVG_ALIGN_TOP);
          nvgText(ls->draw, draw.x + draw.w - rowheight, draw.y, buffer, NULL);
        }
        
        //Draw Team label
        snprintf(buffer, 15, "%s %d", Strings_Get(globalState->strings, STR_TEAM), t->id);
        
        nvgBeginPath(ls->draw);
        nvgTextAlign(ls->draw, NVG_ALIGN_LEFT|NVG_ALIGN_TOP);
        nvgText(ls->draw, draw.x + rowheight, draw.y, buffer, NULL);
        
        draw.y+=rowheight;
      }
    }
      
    nvgFontSize(ls->draw, BOTTOMBAR_HEIGHT / 2);
    
    //Draw Player entries
    if(flags & PLUI_PLAYER_SHOW)
    for(p = t->firstChild; p!=NULL && count < PLAYERLIST_DIVISIONS; p=p->nextTeam)
    {  
      count++;
      IO_RECT pready =
      {
        draw.x + rowheight / 4,
        draw.y + rowheight / 4,
        rowheight / 2,
        rowheight / 2
      };
      SET_COLORTEAM(ls, t->id, List_Count(&connection->teams), 0.7f);
      Draw_Rect(ls, (IO_RECT){draw.x, draw.y + 5, draw.w, rowheight- 10} );
      
      if(flags & PLUI_PLAYER_READY)
      {          
        Draw_Color(ls, COLOR_BLACK);
        Draw_Round(ls, pready);
      }
      
      if(flags & PLUI_PLAYER_SCORE)
      {
        Draw_Color(ls, COLOR_BLACK);
        snprintf(buffer, 15, "%d", p->score);
        nvgBeginPath(ls->draw);
        nvgTextAlign(ls->draw, NVG_ALIGN_CENTER|NVG_ALIGN_MIDDLE);
        nvgText(ls->draw, draw.x + draw.w - rowheight, draw.y + rowheight / 2, buffer, NULL);
      }
      
      if(p != localPlayer)
      {
        drawPlayerName(ls, p->name, draw, flags);
        
        if(flags & PLUI_PLAYER_READY)
        {
          if(p->ready)
          {
            Draw_Color(ls, COLOR_GREEN);
          } else Draw_Color(ls, COLOR_RED);
          Draw_Round(ls, (IO_RECT){pready.x + 2, pready.y + 2, pready.w - 3, pready.h - 3});
        }
      } 
      else 
      {
        //Draw entry for "you"
        drawPlayerName(ls, Strings_Get(globalState->strings, STR_YOU), draw, flags);
      }
      
      draw.y+=rowheight;
    }
  }
}
