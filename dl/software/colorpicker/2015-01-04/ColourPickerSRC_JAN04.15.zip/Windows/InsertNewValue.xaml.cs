/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace ColorPicker
{
    /// <summary>
    /// Handles the max, min, and safe value of textbox
    /// used inside of Tag property
    /// </summary>
    public class InsertNewValueTagInfo
    {
        public InsertNewValueTagInfo() {  }

        public int max;
        public int min;

        public int safe = 0;
    }

    /// <summary>
    /// Interaction logic for InsertNewValue.xaml
    /// </summary>
    public partial class InsertNewValue : Window
    {

        public InsertNewValue()
        {
            InitializeComponent();
        }

#region Functions
    /// <summary>
    /// Updates the safe value with information from a textbox
    /// </summary>
    /// <param name="safeValue">Safe value to update</param>
    /// <param name="sender">Textbox to manipulate</param>
    private TextBox updateNum(TextBox sender)
    {
        InsertNewValueTagInfo taginfo = (InsertNewValueTagInfo)sender.Tag;
        if (string.IsNullOrEmpty(sender.Text))
            taginfo.safe = 0;
        else
        {
            double num = 0;
            bool success = double.TryParse(sender.Text, out num);
            if (success & num >= taginfo.min & num <= taginfo.max)
            {
                sender.Text.Trim();
                taginfo.safe = Convert.ToInt32(sender.Text);
            }
            else
            {
                sender.Text = taginfo.safe.ToString();
                sender.SelectionStart = sender.Text.Length;
            }
        }
        return sender;
    }

    /// <summary>
    /// Gets the X value of dialog
    /// </summary>
    public int getX() { return Convert.ToInt32(XNumber.Text); }

    /// <summary>
    /// Gets the Y value of dialog
    /// </summary>
    public int getY() { return Convert.ToInt32(YNumber.Text); }

    /// <summary>
    /// Sets X parameters
    /// </summary>
    public void setX(InsertNewValueTagInfo tti) { XNumber.Tag = tti; }

    /// <summary>
    /// Sets Y parameters
    /// </summary>
    public void setY(InsertNewValueTagInfo tti) { YNumber.Tag = tti; }
#endregion

#region Events
    private void OK_Button_Click(object sender, RoutedEventArgs e)
    {
        this.DialogResult = true;
    }

    private void Number_TextChanged(object sender, RoutedEventArgs e)
    {
        sender = updateNum((TextBox)sender);
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        InsertNewValueTagInfo xInfo = (InsertNewValueTagInfo)XNumber.Tag;
        InsertNewValueTagInfo yInfo = (InsertNewValueTagInfo)YNumber.Tag;
        this.XRangeLabel.Content = (xInfo.min + "\\" + xInfo.max);
        XNumber.Text = xInfo.safe.ToString();
        this.YRangeLabel.Content = (yInfo.min + "\\" + yInfo.max);
        YNumber.Text = yInfo.safe.ToString();

        if (xInfo.max == -1 || xInfo.min == -1)
        {
            this.XDown.Visibility = System.Windows.Visibility.Collapsed;
            this.XUp.Visibility = System.Windows.Visibility.Collapsed;
            this.XRangeLabel.Visibility = System.Windows.Visibility.Collapsed;
            this.XNumber.Text = "0";
            this.XNumber.IsEnabled = false;
        }

        GlassHelper.ExtendGlass(this, -1);
    }

    private void X_Up_Click(object sender, RoutedEventArgs e)
    {
        InsertNewValueTagInfo tti = (InsertNewValueTagInfo)XNumber.Tag;
        if (tti.safe < tti.max) { XNumber.Text = (Convert.ToInt32(XNumber.Text) + 1).ToString(); }
    }
    private void X_Down_Click(object sender, RoutedEventArgs e)
    {
        InsertNewValueTagInfo tti = (InsertNewValueTagInfo)XNumber.Tag;
        if (tti.safe > tti.min) { XNumber.Text = (Convert.ToInt32(XNumber.Text) - 1).ToString(); }
    }
    private void Y_Up_Click(object sender, RoutedEventArgs e)
    {
        InsertNewValueTagInfo tti = (InsertNewValueTagInfo)YNumber.Tag;
        if (tti.safe < tti.max) { YNumber.Text = (Convert.ToInt32(YNumber.Text) + 1).ToString(); }
    }
    private void Y_Down_Click(object sender, RoutedEventArgs e)
    {
        InsertNewValueTagInfo tti = (InsertNewValueTagInfo)YNumber.Tag;
        if (tti.safe > tti.min) { YNumber.Text = (Convert.ToInt32(YNumber.Text) - 1).ToString(); }
    }
#endregion
    }
}
