/* 
 * Aeden McClain (c) 2016
 * web:   https://platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#include "General.h"
#include "Views.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <plList.h>
#include <plStrings.h>

#include "ServerAPI.h"
#include "Client.h"
#include "Prism.h"
#include "LibHelper.h"
#include "UI/PlayerListUI.h"
#include "UI/ChatUI.h"

#include "Tools.h"

PRIVATE ROOMVIEW* globalRoomView;

PRIVATE IO_RECT playerList =
{
  CANVAS_WIDTH / 4,
  CANVAS_HEIGHT / 4,
  CANVAS_WIDTH / 2,
  CANVAS_HEIGHT / 2
};

PRIVATE IO_RECT chatBounds_focused =
{
  0,
  CANVAS_HEIGHT / 2 - 10,
  CANVAS_WIDTH,
  (CANVAS_HEIGHT / 2) - FONTSIZE_CHAT
};

PRIVATE IO_RECT chatBounds_unfocused = 
{
  0,
  CANVAS_HEIGHT - (3*FONTSIZE_CHAT) - 10,
  CANVAS_WIDTH,
  (2*FONTSIZE_CHAT)
};

IO_COLOR playerColor_in = {70,70,255,255};
IO_COLOR playerColor_out = {175,175,175,255};

bool drawCollisions(IO_RECT rect1, LIST_HEADER type1, IO_RECT rect2, LIST_HEADER type2)
{
  //Draw the object
  if(type2 == HEADER_RECT)
      Draw_Rect(globalState->libs, rect2);
  else if(type2 == HEADER_ROUND)
      Draw_Round(globalState->libs, rect2);

  return true;
}

PRIVATE void drawFlag(NVGcontext* c, int x, int y, int size)
{
  nvgFillColor(c, nvgRGB(0,0,0));
  nvgBeginPath(c);
  nvgMoveTo(c, x     , y);
  nvgLineTo(c, x + 1 , y);
  nvgLineTo(c, x + 1        , y - (size / 3));
  nvgLineTo(c, x + size - 2 , y - (size * 2 / 3));
  nvgLineTo(c, x            , y -  size);
  nvgClosePath(c);
  nvgFill(c);
  
  nvgFillColor(c, nvgRGB(255,255,255));
  nvgBeginPath(c);
  nvgMoveTo(c, x + 1        , y + 1 - size);
  nvgLineTo(c, x + size - 3 , y - (size * 2 / 3));
  nvgLineTo(c, x + 1        , y - (size * 1 / 3) - 0.5);
  nvgClosePath(c);
  nvgFill(c);
  
  return;
}

void drawPlayers(LIBSTATE* ls, LIST players, int teamcount, int gamemode)
{
  if(players)
  {
    CLIENTPLAYER* p;

    foreach(p, players)
    {
      if(p->player.team->id != 0 || gamemode == GAMEMODE_NONE)
      {
        static IO_CIRCLE area;
        area = (IO_CIRCLE){p->player.pos.x, p->player.pos.y, PLAYER_RADIUS};
        Draw_Color(ls, playerColor_out);
        Draw_Circle(ls, area);
        
        if(p->player.stamina == PLAYER_STAMINA_MAX)
          area.r = PLAYER_RADIUS;
        else 
          area.r = (((float)PLAYER_RADIUS / (float)PLAYER_STAMINA_MAX) * (float)p->player.stamina);
        
        area.r --;

        SET_COLORTEAM(ls, p->player.team->id, teamcount, 0.4);
        Draw_Circle(ls, area);
        
        if(p->player.hasFlag)
        {
          drawFlag(ls->draw, p->player.pos.x - 8, p->player.pos.y, FLAG_SIZE);
        }
        
        Draw_Color(ls, COLOR_BLACK);
        Draw_Text(ls, globalState->font, (IO_POINT){p->player.pos.x, p->player.pos.y}, 4.0f, p->player.name);
      }
    }
  }
  return;
}

PRIVATE void drawTeams(LIBSTATE* ls, LIST teams, int teamcount)
{
  TEAM* t;
  int i;
  
  foreach(t, teams)
  {
    int flagx = t->base.x + (t->base.w / 2) - ((t->flagCount / 2)*FLAG_SIZE);
    int flagy = t->base.y + (t->base.h / 2);
    SET_COLORTEAM(ls, t->id, teamcount, 0.5f);
    Draw_Rect(ls, t->base);

    Draw_Color(ls, COLOR_BLACK);
    for(i = 0; i< t->flagCount;i++)
    {
      drawFlag(ls->draw, flagx + (i * FLAG_SIZE), FLAG_SIZE + flagy, FLAG_SIZE);
    }
  }
}

void drawRoomBorder(SERVERCONNECTION* server, LIBSTATE* ls)
{
  IO_RECT zone = (IO_RECT)
      {0,0,server->fgCollisions->roomW, server->fgCollisions->roomH};
  Draw_Color(ls, (IO_COLOR){255,255,255,255});
  Draw_Rect(ls, zone);
}

PUBLIC char* RoomView_init (void* viewData, void* userData)
{
  ROOMVIEW*  view = (ROOMVIEW*)viewData;

  if (!viewData)
  {
    Errors_ThrowFormat(globalState->errors, ERRSEV_FATAL, ERRID_MEM, "GameState");
  }
  else
  {    
    view->server = (SERVERCONNECTION*)userData;
    Errors_ThrowFormat(globalState->errors, ERRSEV_INFO, STR_CLIENT_STARTED, NULL);
    Client_Tick(&view->server);

    return VIEW_CONTINUE;
  }

  return VIEW_BREAK;
}

#define VELKEY(key, dir) \
  if(glfwGetKey(state->libs->window, (key)) == GLFW_PRESS) \
  { if(Client_SetVelocity(state->server, (dir))) result=true;} \

PRIVATE IO_POINT handleKeys(LIBSTATE* ls)
{
    IO_POINT intentVelocity;
    int moveSpeed = (glfwGetKey(ls->window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) ?
      RUN_SPEED : MOVEMENT_SPEED;

    if(glfwGetKey(ls->window, GLFW_KEY_D) == GLFW_PRESS)
      intentVelocity.x = moveSpeed;
    else if(glfwGetKey(ls->window, GLFW_KEY_A) == GLFW_PRESS)
      intentVelocity.x = -moveSpeed;
    else intentVelocity.x = 0;

    if(glfwGetKey(ls->window, GLFW_KEY_S) == GLFW_PRESS)
      intentVelocity.y = moveSpeed;
    else if(glfwGetKey(ls->window, GLFW_KEY_W) == GLFW_PRESS)
      intentVelocity.y = -moveSpeed;
    else intentVelocity.y = 0;

    return intentVelocity;
}

PUBLIC bool Client_UpdateVelocities(SERVERCONNECTION* connection, int amount, IO_POINT intentVelocity)
{
  CLIENTPLAYER* player;
  if(connection->playerStore)
  {
    if(connection->activePlayer)
    {
      PLAYER* p = &connection->activePlayer->player;
      
      if(p->team->id == 0 && connection->gamemode != GAMEMODE_NONE)
      {
        p->pos.x += intentVelocity.x; 
        p->pos.y += intentVelocity.y;
      }
      else
      {
        IO_POINT oldV = p->velocity;
        p->velocity = intentVelocity;
        IO_POINT newV = updateVelocity(p, amount, connection->fgCollisions);
        if(newV.x == 0) p->velocity.x = 0;
        if(newV.y == 0) p->velocity.y = 0;
        
        connection->update_player = (oldV.x != p->velocity.x || oldV.y != p->velocity.y);   
      }
    }

    foreach(player, connection->playerStore)
    {
      if(player != connection->activePlayer)
      {
        player->player.pos.x += player->player.velocity.x * amount;
        player->player.pos.y += player->player.velocity.y * amount;
        
        updateStamina(&player->player, amount);
      }
    }
  }
  return true;
}

PUBLIC char* RoomView_update (void* viewData, EVENTSTATE* e)
{
  ROOMVIEW*  view = (ROOMVIEW*)viewData;
  PLAYER* p = &view->server->activePlayer->player;
  IO_POINT intentVelocity = {0,0};
  int tick;
  
  globalRoomView = view;

  if(!view->chatOpen)
  {
    //Test Key Presses
    intentVelocity = handleKeys(globalState->libs);
  }
  
  if(e)
  {
    unsigned short* buffCursor = (*e).stringBuffer;
    while(*buffCursor != '\000')
    {
      if(view->chatOpen && view->chatat <= MAX_CHAT_SIZE)
      {
        switch(*buffCursor)
        {
          case STRBUF_BACKSPACE:
            if(view->chatat > 0)
            {
              *(view->chatbuffer + view->chatat - 1) = '\000';
              view->chatat--;
            }
            break;
          case STRBUF_ENTER:
            Client_Chat(view->server, view->chatbuffer);
          case STRBUF_ESCAPE:
            view->chatat = 0; 
            memset(view->chatbuffer, 0, MAX_CHAT_SIZE);
            view->chatOpen = false;
            
            //Get keys (to avoid GLFW_STICKY_KEYS)
            glfwGetKey(globalState->libs->window, GLFW_KEY_W);
            glfwGetKey(globalState->libs->window, GLFW_KEY_A);
            glfwGetKey(globalState->libs->window, GLFW_KEY_S);
            glfwGetKey(globalState->libs->window, GLFW_KEY_D);
            
            break;
        }
        
        if(*buffCursor < 255 && view->chatat < MAX_CHAT_SIZE)
        {
          *(view->chatbuffer + view->chatat) = *buffCursor;
          view->chatat++;
        }
      } 
      else
      {
        if(*buffCursor == STRBUF_ESCAPE)
        {
          //Stop player
          intentVelocity = (IO_POINT){0,0};
          //Display game menu
          Views_SetFloat(globalState->views, VIEW_GAMEMENU, view->server);
        }
      }
    
      if(*buffCursor == STRBUF_TAB) view->playersOpen = true;
      if(*buffCursor == STRBUF_UNTAB) view->playersOpen = false;
      if(*buffCursor == 'c')        view->chatOpen = true;
      
      buffCursor ++;
    }
  }
  
  if(p->stamina == 0)
  {
    if(intentVelocity.x == RUN_SPEED)
      intentVelocity.x = MOVEMENT_SPEED;
    else if(intentVelocity.x == -RUN_SPEED)
      intentVelocity.x = -MOVEMENT_SPEED;
    
    if(intentVelocity.y == RUN_SPEED)
      intentVelocity.y = MOVEMENT_SPEED;
    else if(intentVelocity.y == -RUN_SPEED)
       intentVelocity.y = -MOVEMENT_SPEED;
  }
  
  if ((tick = Client_Tick(&view->server)))
  {
    Client_UpdateVelocities(view->server, tick, intentVelocity);
  }
  
  if(!view->server)
    Views_Set(globalState->views, VIEW_MENU, NULL);
  else
  {
    //Target the view on the active player
    CLIENTPLAYER* activePlayer = Server_GetActivePlayer(view->server);
    if(activePlayer)
    {
        view->target.x = (GAME_SCALE * activePlayer->player.pos.x) - (CANVAS_WIDTH / 2);
        view->target.y = (GAME_SCALE * activePlayer->player.pos.y) - (CANVAS_HEIGHT / 2);
    }
  }
  
  UPDATESERVER(&view->server);

  return VIEW_CONTINUE;
}

PRIVATE void drawHUDObj(NVGcontext* draw, int obj, char* text, int val)
{
  int drawcenter = CANVAS_WIDTH - (HUDITEM_WIDTH * obj);
  static char numtext[3];
  static int textbuf = -1;
  
  if(textbuf != val)
  {
    textbuf = val;
    snprintf(numtext, 3, "%d", val);
  }
  
  nvgFontSize(draw, HUD_SIZE * 3 / 4);
  nvgBeginPath(draw);
  nvgTextAlign(draw, NVG_ALIGN_TOP|NVG_ALIGN_CENTER);
  nvgText(draw, drawcenter, 0, numtext, NULL);
  
  nvgFontSize(draw, HUD_SIZE * 2 / 5);
  nvgBeginPath(draw);
  nvgTextAlign(draw, NVG_ALIGN_BASELINE|NVG_ALIGN_CENTER);
  nvgText(draw, drawcenter, HUD_SIZE - 2, text, NULL);
}

PRIVATE void drawHUD(LIBSTATE* globalLibs, SERVERCONNECTION* server, PLAYER* p)
{
  char buffer[10];
  //Draw Game Header
  Draw_Color(globalLibs, HUD_COLOR);
  Draw_Rect(globalLibs, (IO_RECT){0,0,CANVAS_WIDTH, HUD_SIZE});
  
  char* modetext = "";
  
  if(p->team->id == 0 && server->gamemode != GAMEMODE_NONE)
  {
    modetext = Strings_Get(globalState->strings, STR_GM_SPECTATE);
  }
  else
  {  
    //Draw gamemode
    switch(server->gamemode)
    {
      case GAMEMODE_NONE:
        modetext = Strings_Get(globalState->strings, STR_GM_NONE);
        break;
      case GAMEMODE_THRESHOLD:
        modetext = Strings_Get(globalState->strings, STR_GM_THRESHOLD);
        break;
      case GAMEMODE_CONTROL:
        modetext = Strings_Get(globalState->strings, STR_GM_CONTROL);
        break;
      case GAMEMODE_TIMED:
        modetext = Strings_Get(globalState->strings, STR_GM_TIMED);
        break;
      case GAMEMODE_DEBUG:
        modetext = Strings_Get(globalState->strings, STR_GM_DEBUG);
        break;
    }
  }
  
  Draw_Color(globalLibs, COLOR_RED);
  
  nvgFontSize(globalLibs->draw, HUD_SIZE / 2);
  
  nvgBeginPath(globalLibs->draw);
  nvgTextAlign(globalLibs->draw, NVG_ALIGN_LEFT | NVG_ALIGN_MIDDLE);
  nvgText(globalLibs->draw, BUTTON_PADDING, HUD_SIZE / 2, modetext, NULL);
  
  //Draw Score
  Draw_Color(globalLibs, COLOR_BLACK);
  
  int displaytime = server->gametime;
  
  //Count down time if in timed gamemode
  if(server->gamemode == GAMEMODE_TIMED)
    displaytime = server->gamegoal - displaytime;   
  
  snprintf(buffer, 10, "%.2u:%.2u", (int)(displaytime / 60), displaytime % 60);
  
  Draw_Text(globalLibs, globalState->font, (IO_POINT) { CANVAS_WIDTH / 2, HUD_SIZE / 2 }, HUD_SIZE, buffer);
  
  drawHUDObj(globalLibs->draw, 1, GETSTR(STR_SCORE), p->score);
  drawHUDObj(globalLibs->draw, 2, GETSTR(STR_TEAM), p->team->teamscore);
  
  //Draw gamemode specific elements
  if(server->gamemode == GAMEMODE_THRESHOLD)
    drawHUDObj(globalLibs->draw, 5, GETSTR(STR_GM_WINAT), server->gamegoal);
}

PRIVATE void drawChat(LIBSTATE* globalLibs, ROOMVIEW* view)
{
  IO_COLOR chatBoxOutline = view->chatOpen ? COLOR_GREEN : COLOR_RED; 
  nvgStrokeColor(globalLibs->draw, nvgRGB(chatBoxOutline.r, chatBoxOutline.g, chatBoxOutline.b));
  
  Draw_Color(globalLibs, COLOR_WHITE);
  
  nvgBeginPath(globalLibs->draw);
  nvgRect(
    globalLibs->draw, 
    1, 
    CANVAS_HEIGHT - FONTSIZE_CHAT + 1, 
    CANVAS_WIDTH - 2, 
    FONTSIZE_CHAT - 2);
  nvgStroke(globalLibs->draw);
  nvgFill(globalLibs->draw);
  
  nvgBeginPath(globalLibs->draw);
  nvgTextAlign(globalLibs->draw,NVG_ALIGN_LEFT|NVG_ALIGN_TOP);
  nvgFontSize(globalLibs->draw, FONTSIZE_CHAT);
  
  Draw_Color(globalLibs, COLOR_BLACK);
  
  if(view->chatOpen)
  {
    //Draw pending chat
    nvgText(
      globalLibs->draw, 
      2, 
      CANVAS_HEIGHT - FONTSIZE_CHAT + 1,
      view->chatbuffer, NULL);
    
    ChatUI_Draw(globalLibs, chatBounds_focused, view->server);
  } 
  else 
  {
    nvgText(
      globalLibs->draw, 
      2, 
      CANVAS_HEIGHT - FONTSIZE_CHAT, 
      Strings_Get(globalState->strings, STR_INFO_CHAT),
      NULL);
    
    ChatUI_Draw(globalLibs, chatBounds_unfocused, view->server);
  }
}

PUBLIC char* RoomView_draw  (void* viewData)
{
  ROOMVIEW*  view = (ROOMVIEW*)viewData;
  GAMESTATE* glob = (GAMESTATE*)globalState;
  LIBSTATE* globalLibs = glob->libs;

  Draw_Color(globalLibs, (IO_COLOR){0x00,0x00,0x00,0x99});
  Draw_Rect(globalLibs,(IO_RECT){0,0,CANVAS_WIDTH,HUD_SIZE});
  
  if(view->server)
  {
    //Focus the view on the player
    nvgTranslate(globalLibs->draw, -view->target.x, -view->target.y);
    nvgScale(globalLibs->draw, GAME_SCALE, GAME_SCALE);

    glClearColor(0.5,0.5,0.5,1);
    Window_Clear(globalLibs);

    IO_RECT gameZone = {view->target.x / GAME_SCALE, view->target.y / GAME_SCALE,
        CANVAS_WIDTH / GAME_SCALE, CANVAS_HEIGHT / GAME_SCALE};

    int teamcount = List_Count(&view->server->teams);
        
    //Now draw the game area based on the loaded level
    //Draw Border
    drawRoomBorder(view->server, globalLibs);
    //Draw team bases
    drawTeams(globalLibs, view->server->teams, teamcount);
    //Draw Foreground
    Draw_Color(globalLibs, COLOR_FG);
    HandleCollisionData(gameZone, HEADER_RECT, view->server->fgCollisions, drawCollisions);
    //Draw Background
    Draw_Color(globalLibs, COLOR_BG);
    HandleCollisionData(gameZone, HEADER_RECT, view->server->bgCollisions, drawCollisions);
    
    //Now draw players
    drawPlayers(globalLibs, view->server->playerStore, teamcount, view->server->gamemode);
    
    nvgResetTransform(globalLibs->draw);
    drawHUD(globalLibs, view->server, &Server_GetActivePlayer(view->server)->player);
    
    drawChat(globalLibs, view);
    
    if(view->playersOpen)
    {
      Draw_Color(globalLibs, HUD_COLOR);
      Draw_Rect(globalLibs, playerList);
      
      PlayerListUI_Draw(globalLibs, NULL, playerList, view->server, 
                  PLUI_TEAM_SHOW | PLUI_PLAYER_SCORE | PLUI_PLAYER_SHOW | PLUI_TEAM_SCORE);
    }
  }
  
  return VIEW_CONTINUE;
}

PUBLIC char* RoomView_clean (void* viewData)
{
  ROOMVIEW*  view = (ROOMVIEW*)viewData;
  
  if(view->server && view->server->gameStage == GS_INGAME)
    Client_DestroyConnection(&view->server);
  
  return VIEW_CONTINUE;
}

