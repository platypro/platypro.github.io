/* 
 * Aeden McClain (c) 2016
 * web:   https://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

/* Players module...
 * 
 * Handles chat, player ID distribution, orders, and requests.
 * 
 */

#ifndef INC_PLAYERS_H
#define INC_PLAYERS_H

#include <ServerAPI.h>

#define foreachplayer(player, index) foreach(player, index->clients)
#define resetplayer(player, index) player->sendTask = index->taskIndex

struct PlayerContext 
{ 
  struct PlayerIndex* index;
  struct Client* c; 
};

typedef int  (*PLAYERDO)     (void* userdata);

typedef int  (*PLAYERUPDATE) (void* userdata, int tick, struct PlayerContext* index);
typedef char (*PLAYERGEN)    (char* buffer, int buffsize, int signal, void* user, int playerID, bool itself);
typedef int  (*PLAYERGET)    (char header, char* request, void* data, struct PlayerContext* context);

typedef struct ClientMessage
{
  char header;
  char mesg[MAX_MESSAGE_SIZE];
} CLIENTMESSAGE;

typedef struct ClientList
{
  char header;
  SVRGEN callback;
  LIST list;
} CLIENTLIST;

//! Definition of all required data for a single client
typedef struct Client
{
  //! The clients connection data to the server
  SERVERNODE* node;
  
  //! Current position in taskIndex
  LIST sendTask;
  
  //! Current position in taskIndex_Signal
  LIST sendTask_Signal;
  
  //! Pending order to send this player
  SERVERORDER sendTask_Order;
  
  //! Unique ID number. No two players get the same one
  int id;

  //! Number of ticks since last heartbeat
  int tick;
  
  //! Funeral invitation count
  int dead;

  //! User data for player
  void* playerData;
} CLIENT;

typedef struct PlayerIndex
{
  PLAYERGEN    dataGen;
  PLAYERGET    dataRecv;
  PLAYERUPDATE dataUpdate;
  
  //! List of client objects. see struct Client
  LIST clients;
  
  //! List of teams
  LIST teams;
  
  /*! A list with each element representing a signal, 
   *  or group of signals to be sent to all players.
   * 
   * This list is kept in order as new signals arrive.
   * When a player arrives in-game, this list is
   * populated with data for every signal that the
   * player can generate.
   * 
   * At the beginning of the game, general data is added
   * to this list which should be sent to all players.
   * 
   * This list is cleared when the game is closed, and
   * player elements are removed when a client disconnects.
   */
  LIST taskIndex;
  
  /*! A list of signals which need to be destroyed after
   *  being sent to all clients
   * 
   * This list is kept seperate to ease garbage collection
   */
  LIST taskIndex_Signal;
  
  /*! The total number of user signals.
   * 
   * This number represents the total number of tasks added to
   * taskIndex whenever a new player joins. The user can pass
   * values from 0 to (signalCount - 1) to Player_Send which
   * requests that a user signal needs to be sent.
   *
   * The number specified to Player_Send is later passed into 
   * the server generation callback along with the player data
   * itself.
   */
  int signalCount;
  
  //! Next ID to give out
  unsigned int idCount;
  
  size_t playerSize;
  
  int playerCount;
  
  //! Used in Player_Update
  int numChat;
  int ticks;
} PLAYERINDEX;

#define PLAYER_GETCOUNT(player) (player)->playerCount

#define SERVER_MAX_PLAYERS 45

extern PLAYERINDEX* Player_Init(
  size_t playerSize, int signalcount, PLAYERGEN dataGen, PLAYERGET dataRecv, PLAYERUPDATE update);
extern void Player_Clean(PLAYERINDEX** index);

extern void*  Player_Add(PLAYERINDEX* index, SERVERNODE* node, char order, int* pid);

extern void Player_SendAll(PLAYERINDEX* index, char skipstatic);

extern bool Player_Distribute(struct PlayerContext* index, LISTTYPE tasktype);

extern bool Player_PushList(PLAYERINDEX* index, char header, LIST list, SVRGEN format);
extern bool Player_PushMesg(PLAYERINDEX* index, char header, char* mesg);

extern bool Player_Do(PLAYERINDEX* index, PLAYERDO pdo);

extern void Player_Order(PLAYERINDEX* index, char order);
extern bool Player_PushOnce(PLAYERINDEX* index, char header, char* format, ...);

extern bool Player_Update(PLAYERINDEX* index, int ticks);

#endif
