/*
 * Aeden McClain (c) 2017
 * web:   https://platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "General.h"
#include "Views.h"

#include "plStrings.h"
#include "LibHelper.h"
#include "UI/PlayerListUI.h"

#define LISTFLAGS_PLAYERS  PLUI_PLAYER_SCORE | PLUI_PLAYER_SHOW
#define LISTFLAGS_TEAMS    PLUI_TEAM_SHOW | PLUI_TEAM_SCORE

PRIVATE IO_COLOR backColor =
    (IO_COLOR){0xCC,0xFF,0xCC,0xFF};

PRIVATE int ClickEvent_closeintergame(UI_ELEMENT* element, void* state)
{
  SERVERCONNECTION* conn = ((INTERGAMEVIEW*)state)->connection;
  conn->gameStage = GS_WAITFORPLAYERS;
  Views_Set(globalState->views, VIEW_DOWNLOAD, conn);
  return false;
}

#define TEAMLISTX CANVAS_WIDTH / 4
#define TEAMLISTY IGV_TEAMLIST_START
#define TEAMLISTW CANVAS_WIDTH / 2
#define TEAMLISTH CANVAS_HEIGHT - BOTTOMBAR_HEIGHT * 2 - BUTTON_PADDING - IGV_TEAMLIST_START

PRIVATE IO_RECT playerList =
{
  TEAMLISTX,
  TEAMLISTY,
  TEAMLISTW,
  TEAMLISTH,
};

PRIVATE UI_DEF gameviewui[] = 
{
  {
    "",
    UITYPE_BTN,
    STR_MENU_OKAY,
    {
      2 * (CANVAS_WIDTH / 5),
      CANVAS_HEIGHT - BOTTOMBAR_HEIGHT - BUTTON_PADDING,
      1 * (CANVAS_WIDTH / 5),
      BOTTOMBAR_HEIGHT
    },
    ClickEvent_closeintergame,
  },
};

PUBLIC char* IntergameView_init(void* viewData, void* userData)
{
  INTERGAMEVIEW* view = (INTERGAMEVIEW*)viewData;
  
  view->uistate = UI_Create(globalState->libs, NULL, globalState->font);
  view->connection = userData;
  view->listflags = LISTFLAGS_PLAYERS;
  
  Errors_ThrowFormat(globalState->errors, ERRSEV_INFO, STR_GAME_END, NULL);
  
  UI_Object_Auto(view->uistate, gameviewui, sizeof(gameviewui), globalState->strings);
  
  return VIEW_CONTINUE;
}

PUBLIC char* IntergameView_update(void* userdata, EVENTSTATE* e)
{
  INTERGAMEVIEW* view = (INTERGAMEVIEW*)userdata;
  if(e)
    UI_Update(view->uistate, *e, view);
  return VIEW_CONTINUE;
}

PUBLIC char* IntergameView_draw(void* userdata)
{
  NVGcontext* nvg = globalState->libs->draw;
  INTERGAMEVIEW* view = (INTERGAMEVIEW*)userdata;
  
  //Draw background
  Draw_Color(globalState->libs, backColor);
  Draw_Rect(globalState->libs, (IO_RECT){0,0,CANVAS_WIDTH, CANVAS_HEIGHT});
  
  Draw_Color(globalState->libs, COLOR_RED);
  nvgTextAlign(nvg, NVG_ALIGN_BASELINE | NVG_ALIGN_CENTER);
  nvgFontSize(nvg, IGV_TEAMLIST_START);
  nvgBeginPath(nvg);
  nvgText(nvg, CANVAS_WIDTH / 2, IGV_TEAMLIST_START - 4, Strings_Get(globalState->strings, STR_GAME_END), NULL);
  
  PlayerListUI_Draw(globalState->libs, NULL, playerList, view->connection, PLUI_TEAM_SHOW | PLUI_PLAYER_SCORE | PLUI_PLAYER_SHOW | PLUI_TEAM_SCORE);
  
  UI_Draw(view->uistate);
  
  return VIEW_CONTINUE;
}

PUBLIC char* IntergameView_clean(void* userdata)
{
  INTERGAMEVIEW* view = (INTERGAMEVIEW*)userdata;
  free(view->sortedplayers);
  free(view->sortedteams);
  UI_Destroy(&view->uistate);
  return VIEW_CONTINUE;
}
