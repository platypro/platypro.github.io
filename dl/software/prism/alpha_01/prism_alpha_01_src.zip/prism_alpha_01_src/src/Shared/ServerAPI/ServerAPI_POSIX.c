#include "General.h"
#include "ServerAPI.h"

#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

bool Server_Host_P(SERVERNODE* node, char* port)
{
  bool result = false;
  int sockfd = -1;
  struct sockaddr_in server_addr;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd >= -1)
  {
    int optval = 1;
    int optlen = sizeof(optval);
   
    fcntl(sockfd, F_SETFL, O_NONBLOCK);
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, optlen);
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(atoi(port));

    if(bind(sockfd, (struct sockaddr*) &server_addr, sizeof(struct sockaddr_in))>=0)
    {
        listen(sockfd, 5);

        node->addr = server_addr;
        node->fd   = sockfd;
        result = true;
    } else
    {
      Errors_ThrowFormat(node->errormanager, ERRSEV_USERWARN, ERRID_CONNECTION, strerror(errno));
    }
  }
  return result;
}

bool Server_Connect_P(SERVERNODE* node, char* address, char* port)
{
  int result = false;
  int sockfd;
  struct sockaddr_in serv_addr;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd >= -1)
  {
    int optval = 1;
    int optlen = sizeof(optval);
    if(setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, &optval, optlen) == 0) {
      inet_aton(address, &serv_addr.sin_addr);
      serv_addr.sin_family = AF_INET;
      serv_addr.sin_port = htons(atoi(port));

      int err = connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr));

      if (err >= 0)
      {
          //Turn off blocking
          fcntl(sockfd, F_SETFL, O_NONBLOCK);
          //Update Server Connection
          node->fd = sockfd;
          node->addr = serv_addr;
          *(node->sendBuffer) = '\n';
          result = true;
      } 
      else
      {
        Errors_ThrowFormat(node->errormanager, ERRSEV_USERWARN, ERRID_CONNECTION, strerror(errno));
      }
    }
  }
  return result; 
}

bool Server_Accept_P(SERVERNODE* node, SERVERNODE* server)
{
  bool result = false;
  struct sockaddr_in addr;
  socklen_t resultsize = sizeof(struct sockaddr_in);
  int fd = accept(server->fd, 
               (struct sockaddr *) &addr, 
               &resultsize);
  if(fd > (-1))
  {
    //Turn off blocking
    fcntl(fd, F_SETFL, O_NONBLOCK);

    node->fd = fd;
    node->addr = addr;

    Errors_ThrowFormat(node->errormanager, ERRSEV_INFO, STR_CONNECTION_NEW, inet_ntoa(addr.sin_addr));
    result = true;
  } 

  return result;
}
