/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

//This file defines common types for both client and server

#ifndef INC_TYPES_H
#define INC_TYPES_H

//Colors!
#define COLOR_WHITE (IO_COLOR){0xFF,0xFF,0xFF,0xFF}
#define COLOR_BLACK (IO_COLOR){0x00,0x00,0x00,0xFF}
#define COLOR_RED   (IO_COLOR){0xFF,0x00,0x00,0xFF}
#define COLOR_GREEN (IO_COLOR){0x00,0xFF,0x00,0xFF}
#define COLOR_BLUE  (IO_COLOR){0x00,0x00,0xFF,0xFF}

#define COLOR_BG    (IO_COLOR){0xB6,0xB6,0xB6,0xFF}
#define COLOR_FG    (IO_COLOR){0x00,0x00,0x00,0xFF}

#define PLAYER_NAMEMAX 24
#define PLAYER_STAMINA_MAX 90 //< Maximum stamina value

#define SCORE_FLAG 5
#define SCORE_STEAL 1

/*! \brief General-Purpose Rectangle object
 *  Contains x, y, width, and height elements in int format
 */
typedef struct IO_Rect
{
	int x;
	int y;
	int w;
	int h;
} IO_RECT;

/*! \brief A scalable Rectangle Object
    This struct complements IO_RECT, it uses
    percentages discuised as floats, typically
    from a span of 0.0f to 1.0f and beyond
 */
typedef struct IO_FRECT
{
	float x;
	float y;
	float w;
	float h;
} IO_FLOAT_RECT;

/* \brief General-Purpose Coordinate
	An x and y property, similar to a 
	IO_RECT, except without a size
 */
typedef struct IO_Point
{
	int x;
	int y;
} IO_POINT;

/* \brief a RGBA Color
	Represents a color with R, G, and B
	elsements spanning between 0.0f and 
	1.0f. Also includes a transparency
	(alpha) element. 
 */
typedef struct IO_Color
{
	float r; 
	float g;
	float b;
	float a;
} IO_COLOR;

/* \brief a circle object.
	Represents a circle with an X, Y,
	and a radius */
typedef struct IO_CIRCLE
{
	int x;
	int y;
	int r;	
} IO_CIRCLE;

typedef struct IO_ROUND
{
  int x;
  int y;
  int rx;
  int ry;
} IO_ROUND;

// Client/Server types:

typedef enum Direction
{
	DIR_UP,
	DIR_LEFT,
	DIR_RIGHT,
	DIR_DOWN
} DIRECTION;

typedef struct Team
{
  int id;          //!< Team ID
  
  int childCount;  //!< Total count of players
  int teamscore;   //!< Total sum of all team scores for this round
  int flagCount;   //!< Number of flags this team contains
  
  IO_RECT base;    //!< Player base size and position
  
  struct Player* firstChild; //!< First item in linked list of players
} TEAM;

typedef struct Player
{
  int id;
  char name[PLAYER_NAMEMAX];
  
  int score;
  
  bool ready;   //!< Is the player ready to play?
  struct Player* hasFlag; //!< Does the player have a flag? If so, who from?
  
  unsigned char stamina; //!< How much stamina does the player have?
  
  IO_POINT pos;
  IO_POINT velocity;
  
  struct Player* nextTeam; //!< Next teammate
  struct Player* prevTeam; //!< Previous teammate
  
  struct Team* team; //!< Link to team info
} PLAYER;

//Header keys (for identifying objects)
typedef enum list_Header
{
	HEADER_LISTEND,
	HEADER_PLAYER,
	HEADER_PLAYERREM,
	HEADER_GAMEOBJECT,
	HEADER_RECT,
	HEADER_ROUND,
    HEADER_TEAM,
	HEADER_INT,
	HEADER_FG,
	HEADER_BG
} LIST_HEADER;

typedef enum GameStage
{
  //! No state, in menu or initialization
  GS_NOSTATE,
  
  //! Players in lobby, accept players
  GS_WAITFORPLAYERS,
  
  //! Game in play, don't accept players
  GS_INGAME,
  
  //! Between games
  GS_INTERGAME,
} GAMESTAGE;

//Gamemodes
typedef enum GameMode
{
  GAMEMODE_NONE,
  GAMEMODE_DEBUG,
  GAMEMODE_TIMED,
  GAMEMODE_THRESHOLD,
  GAMEMODE_CONTROL
} GAMEMODE;

#endif /* INC_TYPES_H */
