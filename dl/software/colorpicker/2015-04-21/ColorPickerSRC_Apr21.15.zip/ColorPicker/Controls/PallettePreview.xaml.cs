/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ColorPicker
{
    /// <summary>
    /// Interaction logic for PallettePreview.xaml
    /// </summary>
    public partial class PallettePreview : UserControl
    {
        public PallettePreview()
        {
            InitializeComponent();
        }

#region Functions
    /// <summary>
    /// Reset the pallette
    /// </summary>
    /// <param name="segments">No. of segments</param>
    public void Reset(int segments)
    {
        Border b;
        DataGrid.ColumnDefinitions.Clear();

        for(int i = 0; i <= segments; i++){
            ColumnDefinition cd = new ColumnDefinition();
            b = new Border();
            Grid.SetColumn(b, i);
            Grid.SetColumnSpan(b, 2);

            DataGrid.ColumnDefinitions.Add(cd);
            DataGrid.Children.Add(b);
        }
    }

    /// <summary>
    /// set Color of column
    /// </summary>
    /// <param name="c">Brush to paint column</param>
    /// <param name="segment">Segment index to paint</param>
    public void SetColor(Brush c, int segment)
    {
        Border r = (Border)this.DataGrid.Children[segment];
        r.Background = c;
        r.BorderBrush = c;
    }
#endregion

    }
}