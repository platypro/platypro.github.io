#include <Views.h>
/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "General.h"
#include "Views.h"
#include "plStrings.h"

#include <string.h>

int ClickEvent_closemenu(UI_ELEMENT* object, void* state);
int ClickEvent_returntomenu(UI_ELEMENT* object, void* state);

PRIVATE UI_DEF gameMenuViewUI[] = 
{
  {
    "",
    UITYPE_BTN,
    STR_NO,
    {
      (CANVAS_WIDTH / 2) - (CANVAS_WIDTH / 5) - 5,
      3*(CANVAS_HEIGHT / 5),
      CANVAS_WIDTH / 5,
      BOTTOMBAR_HEIGHT
    },
    ClickEvent_closemenu,
  },
  {
    "",
    UITYPE_BTN,
    STR_YES,
    {
      (CANVAS_WIDTH  / 2) + 5,
      3*(CANVAS_HEIGHT / 5),
      CANVAS_WIDTH / 5,
      BOTTOMBAR_HEIGHT
    },
    ClickEvent_returntomenu,
  },
  {
      "",
      UITYPE_LABEL,
      STR_MENU_LEAVECONFIRM,
      {
        (CANVAS_WIDTH / 2) - (CANVAS_WIDTH / 5) - 5,
        2*(CANVAS_HEIGHT / 5),
        2*(CANVAS_WIDTH / 5) + 10,
        CANVAS_HEIGHT / 5
      },
      NULL,
    },
};

int ClickEvent_closemenu(UI_ELEMENT* object, void* state)
{
  Views_CloseFloat(globalState->views);
  return false;
}

int ClickEvent_returntomenu(UI_ELEMENT* object, void* state)
{
  Client_RequestDisconnect(&((GAMEMENUVIEW*)state)->connection);
  Views_CloseFloat(globalState->views);
  return false;
}

char* GameMenuView_init(void* viewData, void* userData)
{
  GAMEMENUVIEW* mv = (GAMEMENUVIEW*)viewData;
  mv->connection = userData;
  mv->ui = UI_Create(globalState->libs, NULL, globalState->font);
  UI_Object_Auto(mv->ui, gameMenuViewUI, sizeof(gameMenuViewUI), globalState->strings);
  
  return VIEW_CONTINUE;
}

char* GameMenuView_update(void* viewData, EVENTSTATE* e)
{
  GAMEMENUVIEW* mv = (GAMEMENUVIEW*)viewData;
  if(e)
    UI_Update(mv->ui, *e, mv);

  return VIEW_CONTINUE;
}

char* GameMenuView_draw(void* viewData)
{
  GAMEMENUVIEW* mv = (GAMEMENUVIEW*)viewData;
  UI_Draw(mv->ui);
  
  return VIEW_CONTINUE;
}

char* GameMenuView_clean(void* viewData)
{
  GAMEMENUVIEW* mv = (GAMEMENUVIEW*)viewData;
  UI_Destroy(&mv->ui);
  return VIEW_CONTINUE;
}

