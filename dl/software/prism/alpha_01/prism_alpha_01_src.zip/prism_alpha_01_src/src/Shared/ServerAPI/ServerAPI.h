/* 
 * Aeden McClain (c) 2016
 * web:   https://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#ifndef INC_SVRAPI_H
#define INC_SVRAPI_H

//Server Debug Traces
//Uncomment to see verbose output
//	#define SERVERDEBUG

//Include Network stuff
#ifdef _WIN32
 #include <winsock2.h>
 #include <ws2tcpip.h>
#else
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <netinet/ip.h>
 #include <arpa/inet.h>
#endif

#include <time.h>

//#include "../General.h"
#include "plList.h"
#include "plTypes.h"
#include "plSignals.h"
#include "Errors.h"

#define MESSAGE_HEADER '\255'
#define MESSAGE_FOOTER '\254'

#define MAX_PLAYER_COUNT 3
#define MAX_MESSAGE_SIZE 515
#define READ_BUFFER_SIZE 1024

#define MSG_USER    2   //< User function reported successful
#define MSG_SUCCESS 1   //< Function reported successful
#define MSG_NOTDONE 0   //< Function needs to be called again
#define MSG_FAIL   -1   //< Function failed
#define MSG_EXIT   -1   //< Function should no longer be called
#define MSG_NOCONN -2   //< Server lost connection

#define SIGNAL_NODATA -1

#define MAX_TIMEOUT 20

#define SIGNAL_BEGIN  1
#define SIGNAL_END    2

#define SIGNAL_HEARTBEAT 3
#define FORMAT_HEARTBEAT ""

#define LIST_NONE 3

typedef int (*SVRGET) (char header, char* request, int listID, void* connection);

/*! Generates a string for a server
	\returns The message header
*/
typedef char (*SVRGEN) (char* string, int maxlen, void* data, int objtype, void* user);

typedef struct ServerNode
{
	#ifdef WINDOWS
		WSADATA w_data;
		SOCKET w_sd;
		char* w_name;	
	#else
		int fd;
		struct sockaddr_in  addr;
	#endif
	
	time_t dirtyTime;
	ERRORMANAGER* errormanager;

	//Properties for recieving data

	char messageBuffer[MAX_MESSAGE_SIZE]; //< Buffer for incomplete messages
	char readBuffer[READ_BUFFER_SIZE];    //< Temporary cache for reads
	int listRecv; //< Stores the ID of the current list which is being recieved
	int bufferAt;

	//Properties for sending data

	char sendBuffer[MAX_MESSAGE_SIZE];
	int listSend;  //< ID of list that is being sent
	LIST nextList; //< Next element of the list that is being sent
	int writeAt;

	//int writeID;
	SVRGEN genfun;  //< Function to convert list elements into strings
	void* userdata; //< User data argument for genfun
} SERVERNODE;

//! Connects to a server
extern SERVERNODE* Server_Connect(ERRORMANAGER* errors, char* address, char* port);

//! Closes a connection to a server
extern bool Server_Close(SERVERNODE** connection);

extern bool Server_CheckBusy(SERVERNODE* server);

extern bool Server_Get(SERVERNODE* node, SVRGET getFunc, void* data);
extern int  Server_Write(SERVERNODE** node);
extern bool Server_Heartbeat(SERVERNODE** node); //! Send a heartbeat signal
extern int  Server_PutList(SERVERNODE** server, LIST list, SVRGEN format, int listID, void* userdata);
extern bool Server_PutMesg(SERVERNODE** server, char header, const char* mesg);

extern SERVERNODE* Server_Host(ERRORMANAGER* errors, char* port);
extern SERVERNODE* Server_Accept(ERRORMANAGER* errors, SERVERNODE* node);

//Platform Code

extern bool Server_Host_P(SERVERNODE* node, char* port);
extern bool Server_Connect_P(SERVERNODE* node, char* address, char* port);
extern bool Server_Accept_P(SERVERNODE* node, SERVERNODE* server);

#endif
