==================
==Cranny Mansion==
==================
Cranny Mansion is a minecraft map in which the goal is simple, to explore a mansion! There are many secrets and easter eggs to be found all around the mansion, be sure to find them all!
We've been working on this map in our spare time for the past year. We hope you enjoy playing it as much as we enjoyed making it.

Gameplay
========
There are two types of secrets in the game to be found. Finding all of each type open up a door in the lobby:

--Secrets--
Secrets are represented by signs spread througout the map. When walking near a sign, a message will show if the secret has not been activated already.

--Journals--
Journals are found in chests throughout the map (except for one!), and once the journal is in your inventory it is registered as found and a message shows up on screen.

Client install instructions:
============================
To install, simply put the folder entitled "map" into your minecraft 'saves' folder. Once put into saves, make sure the minecraft version is set to *1.9.2*. Other versions won't work (for now).

Server Install instructions:
============================
This world runs on Minecraft Server Version 1.9.2 . If you do not have the correct copy of the server software available. It can be downloaded at:
https://s3.amazonaws.com/Minecraft.Download/versions/1.9.2/minecraft_server.1.9.2.jar
Once downloaded, paste the server.properties file as well as the folder entitled "map" into the server's working directory. These can both be found in this archive. 


Troubleshooting
===============
Sometimes a sign doesn't trigger properly. If this happens, make sure the secret has not been activated already. If you are sure of this, just try approaching the secret again.

A couple of the signs in the lobby might become blank after closing the game. This is an issue with the scoreboard system. It should fix itself after you unlock another secret.

Credits
=======
--Map Created by:--
GeneralOfCake
platypro

--Testing--
Hitch_Hawk
Mister_Meh