
#ifndef GENERAL_H
#define GENERAL_H

#define PUBLIC
#define PRIVATE static

#define TRUE 1
#define FALSE 0

#define BOOL      char
#define FLOAT     double
#define int64     int64_t
#define uint64_t  uint64_t

#endif  // GENERAL_H
