ColorPicker Readme file, updated 3/24/2015

This program can be used to convert old-style color and blanking files to RGB files for the new system.

ColorPicker� 2014-2015 Aeden McClain
CIRGB� 2015 by Steven McClain

This code depends on Libsndfile, more info at:
http://www.mega-nerd.com/libsndfile/

==============
==How to Use==
==============
Create palettes by using one using the three 
controls for R,G, and B. Load one by pressing
"load" and specifying a file, and store one by
pressing "Save" Respectively. Reset can be used
to clear one, or all controls.

=================
==How to export==
=================
Step 1:
=======
Open the export window, a window should show up
with fields for Project Name, Directory, and
other conversion settings.

In order to continue: you need a project name
and a VALID project directory. The project name
must not be empty and the directory must exist.

BUG::The folder path MUST NOT HAVE SPACES!!

Step 2:
=======
On the next screen, you can locate your files for
conversion. Files may automatically be found.

In order to continue, all files specified must exist
with exception of Palette. Using "automatic" for the
Palette file will use the current loaded palette.
Otherwise, it is checked like any other file.

Step 3:
=======
Once finished step 2, press Export. A window will appear
showing progress of the conversion. Once finished, the
new window can be closed by pressing the Enter key.

After running the conversion, new files are present in
the project folder: 
 + a config file with project settings
 + Files for Red, Green, and Blue
 + A copy of your palette
 + An HTML swatch to help visualize your palette
 + Any extra files specified in step 2