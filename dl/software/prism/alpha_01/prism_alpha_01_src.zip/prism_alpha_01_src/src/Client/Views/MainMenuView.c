/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "General.h"
#include "Views.h"

#include "plStrings.h"
#include "Prism.h"

#include <string.h>

#include "UI/UI.h"

#define UINAME_USERNAME "UIUser"
#define UINAME_ADDR "UIAddr"
#define UINAME_PORT "UIPort"
#define UINAME_CONNECTING "UIConnecting"

int ClickEvent_dojoin(UI_ELEMENT* object, void* viewdata);
int ClickEvent_autojoin(UI_ELEMENT* object, void* viewdata);
int ClickEvent_goback(UI_ELEMENT*  object, void* viewdata);
int ClickEvent_joingame(UI_ELEMENT* object, void* viewdata);
int ClickEvent_settings(UI_ELEMENT* object, void* viewdata);
int ClickEvent_fullscreen(UI_ELEMENT* object, void* viewdata);
int ClickEvent_leaveSettings(UI_ELEMENT* object, void* viewdata);
int ClickEvent_quitgame(UI_ELEMENT* object, void* viewdata);

PRIVATE UI_DEF joinGameItems[] =
{
    {"", UITYPE_LABEL, STR_MENU_SETADDR      , (IO_RECT){0,0,0,0}, NULL},
    {UINAME_ADDR, UITYPE_TEXTBOX, DEF_SERVER , (IO_RECT){0,0,0,0}, NULL},
    {"", UITYPE_LABEL, STR_MENU_SETPORT      , (IO_RECT){0,0,0,0}, NULL},
    {UINAME_PORT, UITYPE_TEXTBOX, DEF_PORT   , (IO_RECT){0,0,0,0}, NULL},
    {"", UITYPE_BTN, STR_MENU_JOINGAME       , (IO_RECT){0,0,0,0}, ClickEvent_dojoin},
    {"", UITYPE_BTN, STR_MENU_GOBACK         , (IO_RECT){0,0,0,0}, ClickEvent_goback}
};

PRIVATE UI_DEF settingsItems[] =
{
  {"", UITYPE_LABEL, STR_MENU_NAMEINPUT, (IO_RECT){0,0,0,0}, NULL},
  {UINAME_USERNAME, UITYPE_TEXTBOX, " ", (IO_RECT){0,0,0,0}, NULL},
  {"", UITYPE_BTN, STR_MENU_FULLSCREEN, (IO_RECT){0,0,0,0}, ClickEvent_fullscreen},
  {"", UITYPE_BTN, STR_MENU_GOBACK, (IO_RECT){0,0,0,0}, ClickEvent_leaveSettings}
};

PRIVATE UI_DEF menuItems[] =
{
  {"", UITYPE_BTN, STR_MENU_JOINGAME, (IO_RECT){0,0,0,0}, ClickEvent_joingame},
  {"", UITYPE_BTN, STR_MENU_QUICKJOIN, (IO_RECT){0,0,0,0}, ClickEvent_autojoin},
  {"", UITYPE_BTN, STR_MENU_SETTINGS, (IO_RECT){0,0,0,0}, ClickEvent_settings},
  {"", UITYPE_BTN, STR_MENU_EXIT,  (IO_RECT){0,0,0,0}, ClickEvent_quitgame}
};

IO_RECT createButtons(LIST strings, UI_INDEX* ui, UI_DEF* buttons, int numButtons)
{
  int i;
  IO_RECT result = {0,0,0,0};
  int uix   = (CANVAS_WIDTH / 2) - (MENU_BUTTON_WIDTH / 2);
  int cy    = (CANVAS_HEIGHT / 2) -
      ((MENU_BUTTON_HEIGHT + MENU_BUTTON_SPACING) * (numButtons-1) / 2);

  result.x = uix - MENU_BUTTON_SPACING;
  result.y = cy  - MENU_BUTTON_SPACING;

  for(i=0;i<numButtons;i++)
  {    
    char* newtext = NULL;
    buttons[i].dimens = (IO_RECT)
        {uix, cy, MENU_BUTTON_WIDTH, MENU_BUTTON_HEIGHT};
        
    //Auto fill server name and port values from settings
    if(!strcmp(buttons[i].name, UINAME_ADDR))
    {
      newtext = Strings_GetValue(globalState->settingStrings, SETTING_SERVERADDR);
    } 
    else if(!strcmp(buttons[i].name, UINAME_PORT))
    {
      newtext = Strings_GetValue(globalState->settingStrings, SETTING_SERVERPORT);
    }
    
    if(newtext)
    {
      buttons[i].text=newtext; 
    }
        
    buttons[i].text = Strings_Get(strings, buttons[i].text);
    UI_Object_Create(ui, buttons[i]);

    cy+=MENU_BUTTON_HEIGHT + MENU_BUTTON_SPACING;
  }

  result.w = MENU_BUTTON_WIDTH + (2*MENU_BUTTON_SPACING);
  result.h = numButtons * (MENU_BUTTON_HEIGHT + MENU_BUTTON_SPACING) + MENU_BUTTON_SPACING;

  return result;
}

#define setMenu(mv, items, itemsSize) \
  (mv)->nextMenu = items;\
  (mv)->nextMenuSize = itemsSize;

int ClickEvent_fullscreen(UI_ELEMENT* object, void* viewdata)
{
  char* set = globalState->libs->isFullscreen ? SETTINGSTR_FALSE : SETTINGSTR_TRUE;
  
  Strings_Set(&globalState->settingStrings, SETTING_FULLSCREEN, set);
  Window_FullScreen(globalState->libs, set);
  
  return true;
}

int ClickEvent_leaveSettings(UI_ELEMENT* object, void* viewdata)
{
  MENUVIEW* view = (MENUVIEW*)viewdata;
  UI_ELEMENT* nameentry = UI_Object_GetByName(view->uiState,UINAME_USERNAME);
  Strings_Set(&globalState->settingStrings, SETTING_USERNAME, nameentry->text);
  Strings_Write(globalState->settingStrings, DEF_SETTINGSFILE, SETTINGS_HEADER);
  return ClickEvent_goback(object, viewdata);

}

int ClickEvent_dojoin(UI_ELEMENT* object, void* viewdata)
{
  MENUVIEW* view = (MENUVIEW*)viewdata;
  glfwGetKey(globalState->libs->window, GLFW_KEY_ESCAPE);
  view->connectionStatus = CS_CONNECTING;
  return true;
}

int ClickEvent_autojoin(UI_ELEMENT* object, void* viewdata)
{
  MENUVIEW* view = (MENUVIEW*)viewdata;
  setMenu(view, joinGameItems, sizeof(joinGameItems));
  return ClickEvent_dojoin(object, viewdata);
}

int ClickEvent_settings(UI_ELEMENT* object, void* viewdata)
{
  MENUVIEW* view = (MENUVIEW*)viewdata;
  char* nametext = Strings_GetValue(globalState->settingStrings, SETTING_USERNAME);
  
  settingsItems[1].text = nametext ? nametext : "";
  
  setMenu(view, settingsItems, sizeof(settingsItems));
  
  return true;
}

int ClickEvent_goback(UI_ELEMENT* object, void* viewdata)
{ 
  setMenu((MENUVIEW*)viewdata, menuItems, sizeof(menuItems)); 
  return true;
}

int ClickEvent_joingame(UI_ELEMENT* object, void* viewdata)
{ 
  setMenu((MENUVIEW*)viewdata, joinGameItems, sizeof(joinGameItems)); 
  return true;
}

int ClickEvent_quitgame(UI_ELEMENT* object, void* viewdata)
{ 
  Views_Set(globalState->views, VIEW_BREAK, NULL);
  return true;
}

char* MenuView_init (void* viewData, void* userData)
{
  GAMESTATE* glob = globalState;
  MENUVIEW* view = (MENUVIEW*)viewData;

  view->uiState = UI_Create(glob->libs, NULL, glob->font);

  view->menuSize = createButtons(glob->strings, view->uiState, menuItems,
      sizeof(menuItems) / sizeof(UI_DEF));
  return VIEW_CONTINUE;
}

float cycleFloat(float* cycle, float* amount, float max)
{
  if(*cycle + *amount > max || *cycle + *amount < 0)
  {
    *amount = -(*amount);
  }
    *cycle += *amount;

  return *cycle;
}

char* MenuView_update (void* viewData, EVENTSTATE* e)
{
  MENUVIEW* mv = (MENUVIEW*)viewData;
  UI_INDEX* ui = mv->uiState;
  char* addr, *port;

  switch(mv->connectionStatus)
  {
  case CS_MENU:
    if(e)
    UI_Update(ui, *e, mv);    
    break;
  case CS_CONNECTING:
    addr = UI_Object_GetByName(ui, UINAME_ADDR)->text;
    port = UI_Object_GetByName(ui, UINAME_PORT)->text;
    SERVERCONNECTION* s = calloc(1, sizeof(SERVERCONNECTION));
    if(s)
    {
      //Create server state
      s->node = Server_Connect(globalState->errors, addr, port);
      s->chatAt = CHAT_CACHE_SIZE;
      
      //Save server info (for next time)
      Strings_Set(&globalState->settingStrings, SETTING_SERVERADDR, addr);
      Strings_Set(&globalState->settingStrings, SETTING_SERVERPORT, port);
      
      if(s->node)
      {
        char buffer[MAX_MESSAGE_SIZE];
        mv->connection = s;
        mv->roomDownload = Client_InitDownload(s);
        mv->connectionStatus = CS_DOWNLOADING;
        
        //Send our username
        snprintf(buffer, MAX_MESSAGE_SIZE, FORMAT_PNAMEPRINT, 
                 0, Strings_Get(globalState->settingStrings, SETTING_USERNAME));
        
        Server_PutMesg(&mv->connection->node, SIGNAL_PNAME, buffer);
      }
      else
      {
        free(s);
        mv->connectionStatus = CS_MENU;
      }
    } else
    {
      Errors_ThrowFormat(globalState->errors, ERRSEV_FATAL, ERRID_MEM, NULL);
      Views_Set(globalState->views, VIEW_BREAK, NULL);
    }
    break;
  case CS_DOWNLOADING:
    switch(Client_RoomDownload(&mv->roomDownload))
    {
      case MSG_USER:
        mv->connectionStatus = CS_GETTINGPLAYER;
        break;
      case MSG_FAIL:
        mv->connectionStatus = CS_MENU;
        break;
    }
    break;
  case CS_GETTINGPLAYER:
    if(Server_GetActivePlayer(mv->connection) && mv->connection->hasName)
    {     
      switch(mv->connection->gameStage)
      {
        case GS_NOSTATE: break;
        case GS_INGAME:
          Views_Set(globalState->views, VIEW_ROOM, mv->connection);
          break;
        case GS_WAITFORPLAYERS:
          Views_Set(globalState->views, VIEW_DOWNLOAD, mv->connection);
          break;
        case GS_INTERGAME:
          Views_Set(globalState->views, VIEW_INTERGAME, mv->connection);
      }
    } else Server_Update(&mv->connection);    
    break;
  }
  
  //Update menu
  if(mv->nextMenu)
  {
    UI_Object_DestroyAll(mv->uiState);
    mv->menuSize = createButtons(
      globalState->strings,
      mv->uiState,
      mv->nextMenu,
      mv->nextMenuSize / sizeof(UI_DEF)
    );

    mv->nextMenu = NULL;
  }
  
  if(mv->connectionStatus != CS_MENU && mv->connection && glfwGetKey(globalState->libs->window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
  {
    if(mv->roomDownload)
      Client_AbortDownload(&mv->roomDownload);
    else Client_DestroyConnection(&mv->connection);
    
    mv->roomDownload = NULL;
    mv->connectionStatus = CS_MENU;
  }

  return VIEW_CONTINUE;
}

void drawTitle(LIBSTATE* l, IO_RECT* ms)
{
#define COLORSEGMENTS 12.0f //< Number of segments to split hue into
#define VISIBLESEGMENTS 9   //< Number of segments to show

  NVGcontext* n = l->draw;
  NVGpaint p;
  //Draw Rainbow
  int beamh = ((MENUVIEW_PRISMHEIGHT) / (VISIBLESEGMENTS));
  int i;

  for(i = 0; i < VISIBLESEGMENTS; i ++)
  {
    //Current y of beam
    int beamy = ms->y - ((VISIBLESEGMENTS - i) * beamh);
    nvgFillColor(n, nvgHSL(i / COLORSEGMENTS, 0.4f, 0.6f));
    nvgBeginPath(n);
    nvgRect(n, ms->x + MENUVIEW_PRISMWIDTH, beamy, ms->w - MENUVIEW_PRISMWIDTH, beamh * 2);
    nvgFill(n);
  }

  //Draw Triangle
  p = nvgLinearGradient(n,
      ms->x, ms->y - (MENUVIEW_PRISMHEIGHT / 2),
      ms->x + (2*MENUVIEW_PRISMWIDTH), ms->y,
      nvgRGB(160,160,160),
      nvgRGB(50,50,50));

  nvgBeginPath(n);
  nvgMoveTo(n, ms->x, ms->y);

  nvgLineTo(n,
      ms->x + (MENUVIEW_PRISMWIDTH),
      ms->y - MENUVIEW_PRISMHEIGHT);

  nvgLineTo(n,
      ms->x + (2*MENUVIEW_PRISMWIDTH),
      ms->y);

  nvgClosePath(n);

  nvgFillPaint(n, p);
  nvgFill(n);

  nvgBeginPath(n);

  nvgFillColor(n, nvgRGB(0.0f, 0.0f, 0.0f));
  nvgTextAlign(n, NVG_ALIGN_CENTER|NVG_ALIGN_BASELINE);
  nvgFontSize(n,  MENUVIEW_TITLEHEIGHT);
  nvgFontFace(n,  globalState->font);
  nvgText(n,
      ((ms->w - (2*MENUVIEW_PRISMWIDTH)) / 2) + (ms->x) + (2* MENUVIEW_PRISMWIDTH),
      ms->y, GAME_SHORTNAME, NULL);
}

char* MenuView_draw (void* viewData)
{
  MENUVIEW* mv = (MENUVIEW*)viewData;
  LIBSTATE* ls = globalState->libs;

  nvgFillColor(globalState->libs->draw, nvgHSL(mv->backHue, 0.5, 0.3));
  Draw_Rect(globalState->libs, (IO_RECT){0, 0, CANVAS_WIDTH, CANVAS_HEIGHT});

  mv->backHue+=0.001f;

  if(mv->connectionStatus == CS_MENU)
  {
    //Draw the title
    drawTitle(ls, &mv->menuSize);

    //Draw a box around the menu
    Draw_Color(ls, COLOR_WHITE);
    Draw_Rect(ls, mv->menuSize);

    Draw_Color(ls, (IO_COLOR){0xFF,0xFF,0xFF,0x66});
    Draw_Text(ls, globalState->font,
        (IO_POINT){CANVAS_WIDTH/2, CANVAS_HEIGHT - 25},
        25.0f, GAME_INFO);

    UI_Draw(mv->uiState);
  }
  else
  {
    char messageBuffer[50];
    char* messageString = messageBuffer;
    switch(mv->connectionStatus)
    {
    case CS_MENU:
      break;
    case CS_CONNECTING:
      messageString = Strings_Get(globalState->strings, STR_MENU_CONNECTING);
      break;
    case CS_DOWNLOADING:
      snprintf(messageBuffer, 50, "Downloading Room:%d/%d",
          mv->roomDownload->downloadAt, mv->roomDownload->downloadTotal);
      break;
    case CS_GETTINGPLAYER:
      messageString = Strings_Get(globalState->strings, STR_MENU_WAITINGFORPLAYER);
      break;
    }

    Draw_Color(globalState->libs, COLOR_WHITE);
    Draw_Text(globalState->libs, globalState->font,
      (IO_POINT){CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2},
      56.0f,
      messageString);
    
    Draw_Text(globalState->libs, globalState->font,
        (IO_POINT){CANVAS_WIDTH / 2, 2 * CANVAS_HEIGHT / 3}
      , 24.0f, Strings_Get(globalState->strings, STR_MENU_ESCAPEABORT));
  }

  return VIEW_CONTINUE;
}

char* MenuView_clean (void* viewData)
{
  MENUVIEW* mv = (MENUVIEW*)viewData;
  UI_Destroy(&mv->uiState);

  if(mv->connectionStatus == CS_DOWNLOADING)
  {
    Client_AbortDownload(&mv->roomDownload);
  }
  
  return VIEW_CONTINUE;
}
