/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ColorPicker
{
    /// <summary>
    /// Interaction logic for Picker.xaml
    /// </summary>
    public partial class Picker : UserControl
    {
        /// <summary>
        /// all points in the polyline but with original values
        /// </summary>
        PointCollection lineData;

        /// <summary>
        /// index of the currently selected point
        /// </summary>
        int activePoint;

        /// <summary>
        /// Index of the point to be altered from the ContextMenu
        /// </summary>
        int contextPoint;

        /// <summary>
        /// The number of visual divisions of the picker
        /// </summary>
        const int divides = 4;

        /// <summary>
        /// This width is generated when calculating the distance between divides, 
        /// used when resizing the window
        /// </summary>
        int dividewidth = 0;

        int ClickSlack = Properties.Settings.Default.ClickSlack;
        System.Drawing.Size scale = Properties.Settings.Default.scale;

        /// <summary>
        /// Context menu to be shown on right click
        /// </summary>
        ContextMenu cm;

        /// <summary>
        /// User Control Constructor
        /// </summary>
        public Picker()
        {
            InitializeComponent();
            activePoint = -1;

            this.Reset();

            cm = this.FindResource("pointContext") as ContextMenu;
        }

#region Public Functions
    /// <summary>
    /// Sets the brush color
    /// </summary>
    /// <param name="penColor">Brush to paint the User Control with</param>
    public void SetColor(Brush penColor)
    {
        this.lineDraw.Stroke = penColor;
        ghost.Stroke = penColor;
    }

    /// <summary>
    /// Getter for picker line data in pivot points
    /// </summary>
    /// <returns>List of pivot points set inside of the Picker</returns>
    public PointCollection GetLineData() {  return lineData; }

    public void SetLineData(PointCollection ld) { lineData = ld; }

    /// <summary>
    /// Update the points to match User Control Parameters
    /// </summary>
    public void updatePoints()
    {
        //if (this.lineDraw != null)
        {
            this.lineDraw.Points = newPointCollection(lineData);
        }

        List<int> handles = new List<int>();
        int div = (int)Canvas.ActualWidth / divides;
        foreach (UIElement element in Canvas.Children)
        {
            if (element is Line)
            {
                Line l = (Line)element;
                if (l.X1 == l.X2)
                {
                    Double x = l.X1 / dividewidth;
                    x = x * div;
                    l.X1 = x; l.X2 = x;
                    l.Y2 = Canvas.ActualHeight;
                }
                else if (l.Y1 == l.Y2)
                {
                    Double y = Canvas.ActualHeight / 2;
                    l.Y1 = y; l.Y2 = y;
                    l.X2 = Canvas.ActualWidth;
                }
            }
            if (element is Rectangle && element != selection)
            { 
                handles.Add(Canvas.Children.IndexOf(element)); }
        }
        for (int i = handles.Count - 1; i >= 0; i--)
        {
            Canvas.Children.RemoveAt(handles[i]);
        }
        for (int i = 0; i < lineDraw.Points.Count; i++)
        {
            if (i != activePoint)
            {
                Rectangle highlight = new Rectangle();
                Canvas.SetLeft(highlight, lineDraw.Points[i].X - 3);
                Canvas.SetTop(highlight, lineDraw.Points[i].Y - 3);
                highlight.Height = 6;
                highlight.Width = 6;
                highlight.Fill = Brushes.Black;
                Canvas.Children.Add(highlight);
            }
        }

        dividewidth = div;
    }

    /// <summary>
    /// Reset all points to their default value
    /// </summary>
    public void Reset()
    {
        lineData = new PointCollection();
        lineData.Add(new Point(0, 0));
        lineData.Add(new Point(scale.Width, scale.Height));
        updatePoints();
    }
#endregion

#region Private Functions

    public bool GetActive()  { if (activePoint > -1) { return true; } return false; }
    public bool GetOver(Point isOver) { if (isOver.X > this.ActualWidth || isOver.X < -CanvasBorder.BorderThickness.Top || isOver.Y > this.ActualHeight || isOver.Y < -CanvasBorder.BorderThickness.Top) { return false; } return true; }
    public int GetSelected() { return activePoint; }

    /// <summary>
    /// Convert points from full size to physical pixel size
    /// </summary>
    /// <param name="data">list of points in full size</param>
    /// <returns>points in pixel size</returns>
    private PointCollection newPointCollection(PointCollection data)
    {
        PointCollection collection = new PointCollection();
        foreach (Point p in data)
        {
            collection.Add(
                new Point(
                    p.X * (this.Canvas.ActualWidth / scale.Width),
                    this.Canvas.ActualHeight - (p.Y * (this.Canvas.ActualHeight / scale.Height))));
        }
        return collection;
    }
    
    /// <summary>
    /// gets where Point is closest to in memory (X based)
    /// </summary>
    /// <param name="point">where to find memory point</param>
    /// <returns>Index of closest point</returns>
    private int getActivePoint(Point point)
    {
        for (int i = 0; i < lineData.Count; i++)
        {
            if ( (i < lineDraw.Points.Count - 1 && point.X > lineDraw.Points[i].X - ClickSlack && point.X < lineDraw.Points[i + 1].X - ClickSlack)
              || (i == lineData.Count - 1 && point.X > lineDraw.Points[i].X - ClickSlack) )
            {
                return i;
            }
        }
        return -1;
    }

    private Point GetRealValue(Point point) 
    {
        Point p = new Point(
            (int)(point.X * (scale.Width / this.Canvas.ActualWidth)),
            (int)((this.Canvas.ActualHeight - point.Y) * (scale.Height / this.Canvas.ActualHeight)));
        if (p.X < 0) p.X = 0; if (p.Y < 0) p.Y = 0;
        return p;
    }

    /// <summary>
    /// Updates the point
    /// </summary>
    /// <param name="mouse">Place to move point towards</param>
    /// <param name="point">Index of point to move</param>
    public void Update(Point mouse, int point)
    {
        Point p = GetRealValue(mouse);

        if (mouse.Y > this.ActualHeight)
            p.Y = 0;
        else if (mouse.Y < 0)
            p.Y = scale.Height;
        
        if (mouse.X > this.ActualWidth)
            p.X = 0;
        else if (mouse.X < 0)
            p.X = scale.Width;

        if (point == 0 || point == this.lineDraw.Points.Count - 1)
        {
            lineData[point] = new Point(lineData[point].X, p.Y);
        }
        else if (p.X < lineData[point + 1].X && p.X > lineData[point - 1].X)
        {
            lineData[point] = p;
        }
        updatePoints();
    }

    /// <summary>
    /// Update main and ghost polyline
    /// </summary>
    /// <param name="ghost">Ghost Position</param>
    private void updateMove(Point ghost)
    {
        //if ghost is within the control
        if (GetOver(ghost))
        {
            selection.Visibility = Visibility.Visible;

            MouseXY.Visibility = Visibility.Visible;
            Point p = GetRealValue(ghost);
            MouseXY.Content = "X:" + p.X + " Y:" + p.Y;

            if (activePoint > -1)
            {
                Update(ghost, activePoint);

                Canvas.SetTop(selection, lineDraw.Points[activePoint].Y - ClickSlack);
                Canvas.SetLeft(selection, lineDraw.Points[activePoint].X - ClickSlack);
                this.ghost.Visibility = Visibility.Hidden;
            }
            else
            {
                int i = getActivePoint(ghost);
                if (i > -1)
                {
                    if (ghost.X > this.lineDraw.Points[i].X + ClickSlack)
                    {
                        Canvas.SetTop(selection, ghost.Y - ClickSlack);
                        Canvas.SetLeft(selection, ghost.X - ClickSlack);
                        this.ghost.Visibility = Visibility.Visible;
                        this.ghost.Points[0] = lineDraw.Points[i];
                        this.ghost.Points[1] = ghost;
                        this.ghost.Points[2] = lineDraw.Points[i + 1];
                    }
                    else
                    {
                        this.ghost.Visibility = Visibility.Hidden;
                        Canvas.SetTop(selection, lineDraw.Points[i].Y - ClickSlack);
                        Canvas.SetLeft(selection, lineDraw.Points[i].X - ClickSlack);
                        MouseXY.Content = "X:" + lineData[i].X + " Y:" + lineData[i].Y;
                    }
                }
            }
        }
    }

    private void AddLine(Double x1, Double x2, Double y1, Double y2,Brush color, int thick, DoubleCollection dashes)
    {
        Line l = new Line();
        l.Stroke = color;
        l.StrokeDashArray = dashes;
        l.StrokeThickness = 2;
        l.X1 = x1; l.X2 = x2; l.Y1 = y1; l.Y2 = y2;
        Canvas.Children.Add(l);
        Canvas.SetZIndex(l, -1);
    }
#endregion

#region Events
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
        selection.Height = ClickSlack * 2;
        selection.Width  = ClickSlack * 2;

        DoubleCollection dashes = new DoubleCollection();
        dashes.Add(2);
        dashes.Add(2);

        for (int i = 1; i < divides; i++)
        {
            dividewidth = (int)Canvas.ActualWidth / divides;
            int x = dividewidth * i;
            AddLine(x, x, 0, Canvas.ActualHeight, Brushes.Black, 2, dashes);
        }

        Double y = Canvas.ActualHeight / 2;
        AddLine(0, Canvas.ActualWidth, y, y, Brushes.Gray, 1, dashes);

        updatePoints();
    }

    private void HandleButton(Point mouse)
    {
        int i = getActivePoint(mouse);
        if (i >= 0)
        {
            Point p = new Point(
                (int)(mouse.X * (this.Canvas.ActualWidth / scale.Width)),
                (int)((this.Canvas.ActualHeight - mouse.Y) * (this.Canvas.ActualHeight / scale.Height)));

            if (mouse.X > this.lineDraw.Points[i].X + ClickSlack)
            {
                lineData.Insert(i + 1, p);
                activePoint = i + 1;
            }
            else
            {
                activePoint = i;
            }
            updateMove(mouse);
        }
    }

    private void UserControl_MouseEnter(object sender, MouseEventArgs e)
    {
        Point mouse = e.GetPosition(this.Canvas);
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            HandleButton(mouse);
        }
    }

    private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
    {
        Point mouse = e.GetPosition(this.Canvas);
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            HandleButton(mouse);
        }
        MouseXY.Foreground = Brushes.Black;
    }

    private void UserControl_MouseMove(object sender, MouseEventArgs e)
    {
        updateMove(e.GetPosition(this.Canvas));
    }

    private void UserControl_MouseUp(object sender, MouseButtonEventArgs e)
    {
        Point mouse = e.GetPosition(this);
        activePoint = -1;
        selection.Visibility = Visibility.Hidden;
        ghost.Visibility = Visibility.Hidden;

        if (e.ChangedButton == MouseButton.Right)
        {
            int i = getActivePoint(mouse);
            MenuItem pictureBoxMenuItem = (MenuItem)cm.Items.GetItemAt(1);

            if (i == 0 || i == this.lineDraw.Points.Count - 1)
                pictureBoxMenuItem.IsEnabled = false;
            else
                pictureBoxMenuItem.IsEnabled = true;

            if (i > -1
                && mouse.X < this.lineDraw.Points[i].X + ClickSlack
                && mouse.X > this.lineDraw.Points[i].X - ClickSlack
                && mouse.Y < this.lineDraw.Points[i].Y + ClickSlack
                && mouse.Y > this.lineDraw.Points[i].Y - ClickSlack)
            {
                contextPoint = i;
                activePoint = -1;

                cm.PlacementTarget = sender as Rectangle;
                cm.IsOpen = true;
            }
        }
        MouseXY.Foreground = Brushes.Gray;
        updatePoints();
    }

    private void CustomValue_Click(object sender, RoutedEventArgs e)
    {
        InsertNewValue inv = new InsertNewValue();
        int xmin = 0, xmax = 1, ymin, ymax, xsafe, ysafe;
        if (contextPoint > 0)
            xmin = Convert.ToInt32(lineData[contextPoint - 1].X);

        if (contextPoint < lineData.Count - 1)
            xmax = Convert.ToInt32(lineData[contextPoint + 1].X);

        ymax = scale.Height;
        ymin = 0;

        ysafe = (int)lineData[contextPoint].Y;
        xsafe = (int)lineData[contextPoint].X;

        inv.setX(xsafe, xmin, xmax);
        inv.setY(ysafe, ymin, ymax);

        if (inv.ShowDialog() == true)
        {
            lineData[contextPoint] = new Point(
                lineData[contextPoint].X, Convert.ToDouble(inv.getX()));
            lineData[contextPoint] = new Point(
                lineData[contextPoint].Y, Convert.ToDouble(inv.getY()));
            updatePoints();
        }
        contextPoint = -1;
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        lineData.RemoveAt(contextPoint);
        updatePoints();
        activePoint = -1;
    }

    private void UserControl_MouseLeave(object sender, MouseEventArgs e)
    {
        selection.Visibility = Visibility.Hidden;
        ghost.Visibility = Visibility.Hidden;
        MouseXY.Visibility = Visibility.Hidden;
        activePoint = -1;
    }
#endregion
    }
}
