/*
 * Aeden McClain (c) 2016-2017
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SRC_SHARED_STRINGS_H_
#define SRC_SHARED_STRINGS_H_

//
//String IDs
//

//Error Types
#define ERRID_MEM    "et_mem"
#define ERRID_INIT   "et_init"
#define ERRID_CONNECTION  "et_connect"
#define ERRID_KICK        "et_kick"
#define ERRID_SERVERCLOSE "et_close"
#define ERRID_SERVERFULL  "et_full"

//Messages
#define STR_CONNECTION_NEW "str_CONNECTION_NEW"
#define STR_SERVER_NOTEAMS "str_SERVER_NOTEAMS"
#define STR_SERVER_CONNECT "str_SERVER_CONNECT"
#define STR_WINDOW_LOAD    "str_WINDOW_LOAD"
#define STR_CLIENT_STARTED "str_CLIENT_STARTED"
#define STR_DOWNLOAD_STARTED "str_DOWNLOAD_STARTED"
#define STR_DOWNLOAD_FINISHED "str_DOWNLOAD_FINISHED"

//Server Messages
#define STR_SERVER_START "str_SERVER_START"
#define STR_SERVER_STOP  "str_SERVER_STOP"
#define STR_SERVER_READY "str_SERVER_READY"
#define STR_SERVER_EMPTY "str_SERVER_EMPTY"
#define STR_SCRIPT_INIT  "str_SCRIPT_INIT"
#define STR_ROOM_GEN     "str_ROOM_GEN"

//Server Chat Messages
#define STR_CHAT_PJOIN   "str_CHAT_PJOIN"
#define STR_CHAT_PLEAVE   "str_CHAT_PLEAVE"

//User info/tooltip messages
#define STR_INFO_CHAT     "str_INFO_CHAT"

//Game modes
#define STR_GM_TIMED      "str_GM_TIMED"
#define STR_GM_THRESHOLD  "str_GM_THRESHOLD"
#define STR_GM_DEBUG      "str_GM_DEBUG"
#define STR_GM_CONTROL    "str_GM_CONTROL"
#define STR_GM_NONE       "str_GM_NONE"
#define STR_GM_SPECTATE   "str_GM_SPECTATE"

//Menu Item string IDs
#define STR_MENU_JOINGAME "str_MENU_JOIN"
#define STR_MENU_QUICKJOIN "str_MENU_QUICKJOIN"
#define STR_MENU_HOSTGAME "str_MENU_HOST"
#define STR_MENU_SERVERMANAGER "str_MENU_SERVERS"
#define STR_MENU_SETTINGS "str_MENU_SETTINGS"
#define STR_MENU_EXIT          "str_MENU_EXIT"
#define STR_MENU_SETADDR  "str_MENU_SETADDR"
#define STR_MENU_SETPORT  "str_MENU_SETPORT"
#define STR_MENU_GOBACK   "str_MENU_GOBACK"
#define STR_MENU_CONNECTING  "str_MENU_CONNECTING"
#define STR_MENU_OKAY        "str_MENU_OKAY"
#define STR_MENU_CLICKCONTINUE "str_MENU_CLICKCONTINUE"
#define STR_MENU_ESCAPEABORT    "str_MENU_ESCAPEABORT"
#define STR_MENU_READYSTATUS   "str_MENU_READYSTATUS"
#define STR_MENU_NAMEINPUT     "str_MENU_NAME"
#define STR_MENU_FULLSCREEN    "str_MENU_FULLSCREEN"
#define STR_MENU_WAITINGFORPLAYER "str_MENU_WAITFORPLAYER"
#define STR_MENU_CHAT "str_MENU_CHAT"
#define STR_MENU_DISCONNECT "str_MENU_DISCONNECT"
#define STR_USERNAME  "str_USERNAME"

#define STR_YES "str_YES"
#define STR_NO  "str_NO"
#define STR_MENU_LEAVECONFIRM "str_MENU_LEAVECONFIRM"

#define STR_PLAYER "str_PLAYER"

#define STR_TEAM "str_TEAM"
#define STR_TEAM_JOIN "str_TEAM_JOIN"
#define STR_TEAM_DEAD "str_TEAM_DEAD"

#define STR_YOU    "str_YOU"
#define STR_SCORE  "str_SCORE"
#define STR_GM_TIMELEFT "str_GM_TIMELEFT"
#define STR_GM_WINAT    "str_GM_WINAT"
#define STR_GAME_END  "str_GAME_END"

//Setting IDs
#define SETTING_FULLSCREEN "fullscreen"
#define SETTING_USERNAME   "username"

#define SETTING_SERVERADDR "serveraddr"
#define SETTING_SERVERPORT "serverport"

#define SETTINGSTR_TRUE "true"
#define SETTINGSTR_FALSE "false"

#define SETTINGS_HEADER    "Pri'sm Settings file"

#endif /* SRC_SHARED_STRINGS_H_ */
