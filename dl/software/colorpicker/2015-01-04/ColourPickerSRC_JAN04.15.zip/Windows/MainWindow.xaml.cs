/*This file is part of ColourPicker
Copyright © 2014-2015 Aeden McClain

ColourPicker is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ColourPicker is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

using System;
using System.Windows;
using System.Windows.Media;
using System.IO;
using Microsoft.Win32;

namespace ColorPicker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int[] RValues;
        int[] GValues;
        int[] BValues;

        private Boolean loaded = false;

        private int activePicker = -1;
        private int activeSelect = -1;

        /// <summary>
        /// Constructor for mainwindow
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }

        #region Pallette tools
        /// <summary>
        /// Generates a single-channel pallette
        /// </summary>
        /// <param name="chartPoints">Source of channel in pivot points</param>
        /// <param name="scale">length of pallette</param>
        /// <returns>Calculated channel</returns>
        private int[] GeneratePallette(PointCollection chartPoints, int scale)
        {
            int k = 0;
            int[] values = new int[Properties.Settings.Default.scale.Width];
            double s = (chartPoints[chartPoints.Count - 1].X - chartPoints[0].X) / Properties.Settings.Default.scale.Width;

            for (int i = 0; i < chartPoints.Count - 1; i++)
            {
                int slope = (int)(
                    (chartPoints[i + 1].Y - chartPoints[i].Y) /
                    (chartPoints[i + 1].X - chartPoints[i].X));

                for (double j = chartPoints[i].X; j < chartPoints[i + 1].X; j += s)
                {
                    if(k<100)
                    values[k++] = (int)(((j - chartPoints[i].X) * slope) + chartPoints[i].Y);
                }
            }
            return values;
        }

        /// <summary>
        /// Draw this.Pallette with Linedata from RedPicker, GreenPicker, and BluePickerw
        /// </summary>
        private void DrawPallette()
        {
            int width = Properties.Settings.Default.scale.Width;

            if (width > this.Pallette.Width) { width = (int)this.Pallette.Width; }

            RValues = GeneratePallette(this.RedPicker.GetLineData(), width);
            GValues = GeneratePallette(this.GreenPicker.GetLineData(), width);
            BValues = GeneratePallette(this.BluePicker.GetLineData(), width);

            Color c = new Color();
            SolidColorBrush scb;

            for (int i = 0; i < width; i++)
            {
                c.R = (byte)RValues[i];
                c.G = (byte)GValues[i];
                c.B = (byte)BValues[i];
                c.A = 0XFF;
                scb = new SolidColorBrush(c);
                this.Pallette.SetColor(scb, i);
            }
        }
        #endregion

        #region Events
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RedPicker.SetColor(Brushes.Red);
            GreenPicker.SetColor(Brushes.Green);
            BluePicker.SetColor(Brushes.Blue);

            this.Pallette.Reset(Properties.Settings.Default.scale.Width);
            DrawPallette();
            loaded = true;
            GlassHelper.ExtendGlass(this, -1);
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            ColorPicker.Windows.Reset reset = new ColorPicker.Windows.Reset();
            if ((bool)reset.ShowDialog())
            {
                if (reset.resets[0]) { RedPicker.Reset(); }
                if (reset.resets[1]) { GreenPicker.Reset(); }
                if (reset.resets[2]) { BluePicker.Reset(); }
            }

            DrawPallette();
        }

        /// <summary>
        /// Writes the PointCollection Data into human-readable memory 
        /// </summary>
        /// <param name="title">Title of point group</param>
        /// <param name="pc">Collection of points to write</param>
        /// <param name="sw">StreamWriter to write files with</param>
        /// <returns>StreamWriter at the new end of file</returns>
        private StreamWriter WritePoints(String title, PointCollection pc, StreamWriter sw)
        {
            sw.WriteLine("_" + title);
            foreach (Point p in pc) { sw.WriteLine(p.X + "|" + p.Y + "|"); }
            sw.WriteLine("end");
            return sw;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            // Set filter for file extension and default file extension
            sfd.DefaultExt = ".txt";
            sfd.Filter = "Text documents (.txt)|*.txt";

            // Display OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = sfd.ShowDialog();

            if (result == true)
            {
                StreamWriter sw = new StreamWriter(sfd.FileName);
                sw.WriteLine("#ColorPicker pallette file");
                sw.WriteLine("#Each line is a pivot point");

                WritePoints("Red"  , RedPicker.GetLineData()  , sw);
                WritePoints("Green", GreenPicker.GetLineData(), sw);
                WritePoints("Blue" , BluePicker.GetLineData() , sw);

                sw.Close();
            }

        }

        /// <summary>
        /// Get the next points in file
        /// </summary>
        /// <param name="sr">StreamReader to read file with</param>
        /// <returns>a pointCollection</returns>
        private PointCollection GetPoints(ref StreamReader sr)
        {
            PointCollection pc = new PointCollection();
            String process;
            String x, y;
            Point build;
            int buildValue;
            process = sr.ReadLine();
            while (process != "end")
            {
                buildValue = 0;
                x = ""; y = "";
                foreach (Char c in process)
                {
                    if (c == '|') { buildValue++; }
                    else
                    {
                        if (buildValue == 0) { x += c; }
                        if (buildValue == 1) { y += c; }
                    }
                }
                build = new Point( Convert.ToInt32(x), Convert.ToInt32(y) );
                pc.Add(build);
                process = sr.ReadLine();
            }
            return pc;
        }

        private void Load_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            // Set filter for file extension and default file extension
            ofd.DefaultExt = ".txt";
            ofd.Filter     = "Text documents (.txt)|*.txt";

            // Display OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = ofd.ShowDialog();

            if (result == true)
            {
                StreamReader sr = new StreamReader(ofd.FileName);
                while (!sr.EndOfStream)
                {
                    int peek = sr.Peek();
                    if (peek == '#') { sr.ReadLine(); };
                    if (peek == '_')
                    {
                        switch (sr.ReadLine().Substring(1))
                        {
                            case "Red":
                                RedPicker.SetLineData(GetPoints(ref sr));
                                RedPicker.updatePoints();
                                break;
                            case "Green":
                                GreenPicker.SetLineData(GetPoints(ref sr));
                                GreenPicker.updatePoints();
                                break;
                            case "Blue":
                                BluePicker.SetLineData(GetPoints(ref sr));
                                BluePicker.updatePoints();
                                break;
                        }
                    }
                }
                DrawPallette();
            }

        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {

            if (loaded == true)
            {
                this.RedPicker.updatePoints();
                this.GreenPicker.updatePoints();
                this.BluePicker.updatePoints();

                DrawPallette();
            }
        }

        private void Grid_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
            {
                DrawPallette();
            }
        }
        #endregion

        private void Window_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e) { activePicker = -1; }

        private void Window_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (RedPicker.GetActive()) { activePicker = 0; activeSelect = RedPicker.GetSelected(); }
            else if (GreenPicker.GetActive()) { activePicker = 1; activeSelect = GreenPicker.GetSelected(); }
            else if (BluePicker.GetActive()) { activePicker = 2; activeSelect = BluePicker.GetSelected(); }
        }

        private void Window_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (activePicker == 0 && !RedPicker.GetOver(e.GetPosition(RedPicker)) )
                RedPicker.Update(e.GetPosition(RedPicker), activeSelect);
            else if (activePicker == 1 && !GreenPicker.GetOver(e.GetPosition(GreenPicker)))
                GreenPicker.Update(e.GetPosition(GreenPicker), activeSelect);

            else if (activePicker == 2 && !BluePicker.GetOver(e.GetPosition(BluePicker)))
                BluePicker.Update(e.GetPosition(BluePicker), activeSelect);
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            Windows.About about = new Windows.About();
            about.ShowDialog();
        }
    }
}
