#ifndef INC_PRISM_SERVER
#define INC_PRISM_SERVER

/** \file Prism Server Header
 *  \addtogroup Prism-Server
 */
/** @{ */

#include "RoomLoader.h"
#include <Errors.h>
#include <ServerAPI.h>
#include <Tools.h>
#include "Players.h"

#define SERVER_PLAYERNAME "Server"

#define CHEAT_FUDGE 3

#define PLAYERPOS_DEFAULT 15

// Everything stored in server state,
// this stuff is usually set only once
typedef struct ServerState
{
  //! Static level data to be sent to all players
  LEVELDATA* levelData;

  //! Collision Data for the level (saves per-move time)
  COLLISIONLIST* collisionData;

  //! Index of strings, as loaded at the beginning of the program
  LIST strings;

  //! Manager in charge of logging, and display of errors
  ERRORMANAGER* errors;
  
  //! ServerAPI object
  SERVERNODE* server;

  //! The loaded script data
  SCRIPTSTATE* script;

  //! Player index
  PLAYERINDEX* players;
  
  ///////////////////////////////////////////////////////
  
  //! Total count of players ready
  int playerReadyCount;
  
  //! Tick counter for determining seconds
  int secondTick; 

  //! Current game status
  GAMESTAGE gs;
  
  //! Current game mode (win state)
  GAMEMODE gm;
  
  //! Goal for current gamemode
  int gameGoal;
  
  //! time since game started
  int gameTime;

} SERVERSTATE;

typedef struct ServerPlayer
{
  bool PositionOverride;
  bool spectate; //!< Buffer value for whether player is spectating
  bool recvd; //! Whether data has been recieved on this tick
  TEAM* teamCollision; //! Whether player is on a team's base
  TEAM* teamFlag; //! Flag has had their flag stolen by this player. Everyone needs to know
  PLAYER player;
} SERVERPLAYER;

extern SERVERSTATE* globalServerState;

/** @} */

#endif
