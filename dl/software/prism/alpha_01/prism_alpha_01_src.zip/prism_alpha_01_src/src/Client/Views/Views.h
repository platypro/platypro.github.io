/*
 * Aeden McClain (c) 2016-2017
 * web:   https://platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SRC_CLIENT_VIEWS_VIEWS_H_
#define SRC_CLIENT_VIEWS_VIEWS_H_

#include "Prism.h"
#include "plList.h"
#include "Client.h"

typedef struct GameView
{
  char* viewName;
  void*     data; //< Stores view data
  size_t dataSize;

  char* (*init)   (void* userdata, void* passin);
  char* (*update) (void* userdata, EVENTSTATE* e);
  char* (*draw)   (void* userdata);
  char* (*clean)  (void* userdata);
} GAMEVIEW;

typedef struct ViewManager
{
  GAMEVIEW*   current; //!< The Pri'sm state
  GAMEVIEW*   next;    //!< The next active Pri'sm state

  void* nextdata;      //!< Data to be sent to the next GAMEVIEW

  GAMEVIEW* floatview; //!< A floating view

  LIST viewIndex;      //!< An index of all views
  bool doBreak;        //!< A flag for whether to quit the view loop
} VIEWMANAGER;

extern VIEWMANAGER* Views_Init();
extern void         Views_Cleanup(VIEWMANAGER** views);

extern bool Views_Create(VIEWMANAGER* views,
    char* viewName,
    size_t dataSize,
    char* (*init)   (void* userdata, void* passin),
    char* (*update) (void* userdata, EVENTSTATE* e),
    char* (*draw)   (void* userdata),
    char* (*clean)  (void* userdata));

extern bool         Views_Set(VIEWMANAGER* vm, char* name, void* userdata);
extern bool         Views_SetFloat(VIEWMANAGER* vm, char* name, void* userdata);
extern bool         Views_CloseFloat(VIEWMANAGER* vm);
extern bool         Views_Remove(VIEWMANAGER* vm, char* name);

#define VIEW_CONTINUE "__VIEWDOCONTINUE" //< Continue to drawing
#define VIEW_BREAK "__VIEWDOBREAK"    //< Don't draw

extern bool Views_Update (LIBSTATE* ls, EVENTSTATE* e, VIEWMANAGER* vm);
extern bool Views_Draw   (LIBSTATE* ls, VIEWMANAGER* vm);

#define VIEW_MENU     "menuView"
#define VIEW_DOWNLOAD "downloadView"
#define VIEW_ROOM     "roomView"
#define VIEW_MESSAGE  "messageView"
#define VIEW_INTERGAME "intergameView"
#define VIEW_GAMEMENU  "gamemenuView"

//Server update macro
#define UPDATESERVER(connection) \
  if(!Server_Update(connection))    Views_Set(globalState->views, VIEW_MENU, NULL); \
  else if((*connection)->gameStage == GS_INTERGAME) Views_Set(globalState->views, VIEW_INTERGAME, *connection);

//////////////////////////////
//        MenuView          //
//////////////////////////////

#define MENU_BUTTON_WIDTH 400
#define MENU_BUTTON_HEIGHT 40
#define MENU_BUTTON_SPACING 15
#define MENU_GAMEICON_HEIGHT 50

typedef enum ConnectionState
{
  CS_MENU,
  CS_CONNECTING,
  CS_DOWNLOADING,
  CS_GETTINGPLAYER
} CONNECTIONSTATE;

typedef struct MenuView
{
  UI_INDEX* uiState;

  SERVERCONNECTION* connection;

  ROOMDOWNLOAD* roomDownload;

  CONNECTIONSTATE connectionStatus; //!< Determines whether to try connecting to server during update
  float backHue; //!< Background color of menu

  IO_RECT menuSize;
  int titleImageID;
  
  UI_DEF* nextMenu;
  size_t nextMenuSize;
} MENUVIEW;

#define MENUVIEW_PRISMWIDTH  60
#define MENUVIEW_PRISMHEIGHT 90
#define MENUVIEW_TITLEHEIGHT 130.0f

extern char* MenuView_init   (void* viewData, void* userData);
extern char* MenuView_update (void* viewData, EVENTSTATE* e);
extern char* MenuView_draw   (void* viewData);
extern char* MenuView_clean  (void* viewData);

////////////////////////
//    DownloadView    //
////////////////////////

typedef struct DownloadView
{
  //bool isWaitingForClose; //< Flag for determining where connection is presumably shutting down
  UI_INDEX* uiState;

  /*! The state of connection to the server. This is the only data that retains
      outside of this view.
    */
  SERVERCONNECTION* connection;
  
  EVENTSTATE e; //!< Event state (for player list interaction)
} DOWNLOADVIEW;

#define BUTTON_READY_WIDTH 250
#define BOTTOMBAR_HEIGHT 50
#define TEAMLABEL_HEIGHT 35
#define BUTTON_PADDING 15
#define PLAYERENTRY_SPACING 5

#define PLAYERLIST_TOP (1.5*BUTTON_PADDING) + (2*BOTTOMBAR_HEIGHT)

extern char* DownloadView_init   (void* viewData, void* userData);
extern char* DownloadView_update (void* viewData, EVENTSTATE* e);
extern char* DownloadView_draw   (void* viewData);
extern char* DownloadView_clean  (void* viewData);

///////////////////////////
//        RoomView       //
///////////////////////////

typedef struct RoomView
{
  SERVERCONNECTION* server;
  IO_POINT target;
  
  char chatbuffer[MAX_CHAT_SIZE];
  char chatat;
  
  bool chatOpen;
  bool playersOpen;
} ROOMVIEW;

#define PLAYER_DEFAULT_X   PLAYER_RADIUS
#define PLAYER_DEFAULT_Y   PLAYER_RADIUS

//Sizes and values
#define HUD_SIZE 64
#define HUD_SPACING 5
#define HUD_COLOR (IO_COLOR){0x99,0xFF,0x99,0xFF}
#define GAME_SCALE 5
#define HUDITEM_WIDTH 100
#define FLAG_SIZE 10

#define TICK_LENGTH 5000

extern char* RoomView_init   (void* viewData, void* userData);
extern char* RoomView_update (void* viewData, EVENTSTATE* e);
extern char* RoomView_draw   (void* viewData);
extern char* RoomView_clean  (void* viewData);

/////////////////////////////
//       MessageView       //
/////////////////////////////

typedef struct MessageView
{
  bool xButtonHighlight;
  char message[255];
} MESSAGEVIEW;

extern char* MessageView_init   (void* viewData, void* userData);
extern char* MessageView_update (void* viewData, EVENTSTATE* e);
extern char* MessageView_draw   (void* viewData);
extern char* MessageView_clean  (void* viewData);

/////////////////////////////
//      InterGameView      //
/////////////////////////////

typedef struct IntergameView
{
  SERVERCONNECTION* connection;
  UI_INDEX* uistate;
  PLAYER** sortedplayers;
  TEAM**   sortedteams;
  int listflags;
} INTERGAMEVIEW;

extern char* IntergameView_init(void* viewData, void* userData);
extern char* IntergameView_update(void* userdata, EVENTSTATE* e);
extern char* IntergameView_draw(void* userdata);
extern char* IntergameView_clean(void* userdata);

#define IGV_OPTION_WIDTH 125
#define IGV_TEAMLIST_START 50

extern GAMEVIEW gameViews[6];

/////////////////////////////
//       GameMenuView      //
/////////////////////////////
typedef struct GameMenuView
{
  UI_INDEX* ui;
  SERVERCONNECTION* connection;
} GAMEMENUVIEW;

extern char* GameMenuView_init(void* viewData, void* userData);
extern char* GameMenuView_update(void* userdata, EVENTSTATE* e);
extern char* GameMenuView_draw(void* userdata);
extern char* GameMenuView_clean(void* userdata);

#endif /* SRC_CLIENT_VIEWS_VIEWS_H_ */
