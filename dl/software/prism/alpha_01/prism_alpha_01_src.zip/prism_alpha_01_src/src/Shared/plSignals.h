/*
 * Aeden McClain (c) 2016
 * web:   http://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

//This file defines signals between both client and server

#ifndef INC_SIGNALS_H
#define INC_SIGNALS_H

#define SIGNAL_CHAT        04  //!< Chat Message
#define SIGNAL_ORDER       05  //!< Give the client an order

#define SIGNAL_ROOMDATA    10  //!< General Download data, required sending before gameplay.
#define SIGNAL_GAMEMODE    11  //!< Set the gamemode
#define SIGNAL_PLYRID      12  //!< "This is your player id", sent before all other signals

#define SIGNAL_PNAME       20  //!< Player name
#define SIGNAL_TEAM        21  //!< Sets a player's team
#define SIGNAL_PREADY      22  //!< Data useful for download screen
#define SIGNAL_PLAYER      23  //!< Data useful during gameplay

#define SIGNAL_PLAYERDEAD  40  //!< A request to remove player from player list
#define SIGNAL_SCORE       41  //!< Sets a player score
#define SIGNAL_STAMINA     42  //!< Sets stamina

#define SIGNAL_TEAMFLAG    51  //!< Sets a team flag area
#define SIGNAL_FLAG        52  //!< Sets player flag data
#define SIGNAL_TRANSFER    53  //!< Team flag transfer

#define SIGNAL_KILLREQUEST 100 //!< Request a disconnect
#define SIGNAL_RECT        101 //!< Rectangle type
#define SIGNAL_ROUND       102 //!< Round Type

//List Headers
#define LIST_FG 4
#define LIST_BG 5
#define LIST_FLAG 6

//Orders
typedef enum ServerOrder
{
  ORDER_NONE,
  ORDER_KICK,
  ORDER_SERVERCLOSE,
  ORDER_SERVERFULL,
  ORDER_BEGINGAME,
  ORDER_DEADTEAM,
  ORDER_PLIST,
  ORDER_ENDGAME
} SERVERORDER;

//Signal Formats
#define FORMAT_PLYRID "%d" //Player ID
#define FORMAT_DOWNLOADDATA "%d_%d_%d" //Download Size, Room (W, H), Gamemode

#define FORMAT_GAMEMODE "%d_%d"

#define FORMAT_TRANSFER "%d_%d"

//Used for score signal and flag symbol
#define FORMAT_SCORE "%d_%d_%d" //Player, Player Score, Team Score

//ID, Velocity (X,Y), Position (X,Y)
#define FORMAT_PLAYER "%d_%d_%d_%d_%d"

//PID, Player Flag, TeamID, Team Flags
#define FORMAT_FLAG "%d_%d_%d_%d"

//ID, Player Name
#define FORMAT_PNAMEPRINT  "%d_%s\t"
#define FORMAT_PNAME       "%d_%[^\t]"

#define FORMAT_CHAT        "%[^\t]"
#define FORMAT_CHATPRINT   "%s\t"

//Ready status of player
//ID, Ready Status
#define FORMAT_INT "%d_%d"

#define FORMAT_RECT     "%d_%d_%d_%d" // X, Y, W, H

//Common values
#define MOVEMENT_SPEED 2
#define RUN_SPEED 3
#define PLAYER_RADIUS  10

#define MAX_CHAT_SIZE 100
 
extern const char* DIRS[];

#endif
