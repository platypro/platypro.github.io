//General Headers
//These are pretty basic

#ifndef INC_GENERAL_H_
#define INC_GENERAL_H_

#define VERSION_NAME      "Pri'sm: The Maze Game"
#define VERSION_AUTHOR    "(c) 2016-2017 Aeden McClain"
#define VERSION_LICENSE   "This program is released under the GNU GPL v3. You are free to change and redistribute it."
#define VERSION_WARRANTY  "Please note that this program is provided WITHOUT ANY WARRANTY."
#define VERSION           "alpha_01"

//Definition for bool value
#define bool int
//True and False Definitions
#define false 0
#define true !false //!< It's funny because it's true

//Public and Private Definitions
#define PUBLIC
#define PRIVATE static

#ifdef _WIN32
	#define WINDOWS
#elif __linux__
	#define LINUX
#endif

#define NUMELEMENTS(array) sizeof(array) / sizeof(*array)

#ifndef NULL
#define NULL 0
#endif

#include "Shared/Strings.h"

#endif
