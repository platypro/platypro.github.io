#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#include "General.h"
#include "readPalette.h"

#define uint64_t  int64_t
#include <sndfile.h>

/* This will be the length of the buffer used to hold samples while
** we process them.
*/
#define BUFFER_LEN      1024

/* libsndfile can handle more than 1 channels but we'll restrict it to 1. */
#define MAX_CHANNELS    1

#define FILTER_COEFF 8

#define ASCII_CR 10
#define ASCII_LF 13

#define BUFF_SIZE 100
#define MAXV 2.0

typedef struct
{
	sf_count_t count;  // total number of samples.

	FLOAT minf;			// Filtered minimum.
	FLOAT maxf;			// Filtered maximum.
	FLOAT minr;			// Raw minimum.
	FLOAT maxr;			// Raw maximum.

	BOOL isFiltSet;
	FLOAT filt;

} MINMAX;


typedef struct 
{
	char *palette_fname;
	char *color_fname;
	char *blanking_fname;
	char *red_fname;
	char *green_fname;
	char *blue_fname;

	MINMAX color_minmax;
	MINMAX blanking_minmax;

	SF_INFO sfinfo;
 	SNDFILE *color_infile;
 	SNDFILE *blank_infile;
    SNDFILE *red_outfile;
    SNDFILE *green_outfile;
    SNDFILE *blue_outfile;

    FLOAT color_fudge;
    FLOAT blanking_fudge;
    FLOAT output_gain;
	int   sample_offset;
	BOOL  invert_colors;

} CIRGB;


typedef struct 
{
	char *Project_Name;
	char *Base_Dir;
	char *Palette_Name;
	char *Blanking_Fudge;
	char *Color_Fudge;
	char *Output_Gain;
	char *Sample_Offset;
	char *Invert_Colors;

} CIRGB_CFG;

CIRGB_CFG cfg;


PRIVATE BOOL isEol(char ch)
{
	return (ch == ASCII_CR || ch == ASCII_LF);
}


PRIVATE char *Base_FileName(char *fname)
{
	char *p = fname;

	if (fname)
	{
		p += strlen(fname);

		while (p != fname && *p != '\\' && *p != ':') { --p; }
	}

	return p;
}

PRIVATE char *Next_Line( char *start )
{
	char *buf = start;

	while ( *buf && !isEol(*buf) ) { ++buf; }

	if (isEol(*buf)) { *buf++ = 0; }
	if (isEol(*buf)) { *buf++ = 0; }

	return buf;
}


PRIVATE void dump_cfg(void)
{
	printf("\
\tBase_Dir '%s'\n\
\tProject_Name '%s'\tPalette_Name '%s'\n\
\tBlanking_Fudge '%s'\tColor_Fudge '%s'\n\
\tOutput_Gain '%s'\tSample_Offset '%s'\t%s\n\
",
	cfg.Base_Dir,
	cfg.Project_Name,	cfg.Palette_Name,
	cfg.Blanking_Fudge,	cfg.Color_Fudge,
	cfg.Output_Gain,	cfg.Sample_Offset, cfg.Invert_Colors ? "Invert Colors" : "");
}


PRIVATE BOOL read_cirgb_cfg( char *fname )
{
	BOOL result = FALSE;
	FILE *fd = fopen(fname, "rb");

	memset( &cfg, 0, sizeof(cfg) );

	if (fd)
	{
		char *buf;
		size_t len;

		fseek(fd, 0, SEEK_END);
		len = ftell(fd);
		rewind(fd);

		printf("Read config '%s' size %d\n", fname, len);

		if ( (buf = malloc(len+1)) )
		{
			if (fread( buf, len, 1,fd) == 1)
			{
				buf = Next_Line( (cfg.Project_Name   = buf) );
				buf = Next_Line( (cfg.Base_Dir       = buf) );
				buf = Next_Line( (cfg.Palette_Name   = buf) );
				buf = Next_Line( (cfg.Blanking_Fudge = buf) );
				buf = Next_Line( (cfg.Color_Fudge    = buf) );
				buf = Next_Line( (cfg.Output_Gain    = buf) );
				buf = Next_Line( (cfg.Sample_Offset  = buf) );
				buf = Next_Line( (cfg.Invert_Colors  = buf) );

				dump_cfg();
			}
		}

		fclose(fd);
		result = TRUE;
	}
	else { printf("Can't read config '%s'!\n", fname); }

	return result;
}

PRIVATE void fixScale(sf_count_t count, FLOAT *buf)
// Convert float from -1 to +1 range to 0 to +1.
{
	int i;
	for (i=0; i<count; ++i)
	{
		*buf += 1.0;
		*buf *= 0.5;
		++buf;
	}
}


PRIVATE void Zap_MinMax( MINMAX *mm )
{
	memset(mm, 0, sizeof(MINMAX));
	mm->minf = MAXV;
	mm->minr = MAXV;
}


PRIVATE FLOAT filt( FLOAT ov, FLOAT nv, FLOAT cof )
{
	return ((ov / cof) * (cof-1)) + (nv / cof);
}


PRIVATE void MinMax_Update(MINMAX *mm, FLOAT *ubuf, sf_count_t n)
{
	for (int i=0; i<n; ++i)
	{
		FLOAT v = *ubuf;

		if ( v > mm->maxr ) { mm->maxr = v; }
		if ( v < mm->minr ) { mm->minr = v; }

		if (!mm->isFiltSet)
		{
			mm->isFiltSet = TRUE;
			mm->filt = v;
		}
		else { v = mm->filt = filt(mm->filt, v, FILTER_COEFF); }

		if ( v > mm->maxf ) { mm->maxf = v; }
		if ( v < mm->minf ) { mm->minf = v; }

		++ubuf;
	}

	mm->count += n;
}


PRIVATE void MinMax_dump(char *name, MINMAX *mm)
{
	printf("MinMax '%s':\n\tminf %f, maxf %f, \n\tminr %f, maxr %f, \n\tdiffmin %f, diffmax %f,\n\tspan %f\n",
		Base_FileName(name), mm->minf, mm->maxf, mm->minr, mm->maxr, mm->minr - mm->minf, mm->maxr - mm->maxf, mm->maxr - mm->minr);
}

PRIVATE int MinMax_Read(char *fname, MINMAX *mm)
{
	SF_INFO sfinfo;
 	SNDFILE *infile = sf_open(fname, SFM_READ, &sfinfo);

	printf("Calculating...");
	fflush(stdout);

	if (infile)
	{
	    if (sfinfo.channels > MAX_CHANNELS)
	    {
		    sf_close(infile);
	        printf ("  Not able to process more than %d channels!\n", MAX_CHANNELS) ;
	        return  1;
	    }

		{
			sf_count_t blockcount = 0;
		    sf_count_t readcount;
			static FLOAT buf[BUFFER_LEN];

		    while ((readcount = sf_read_double(infile, buf, BUFFER_LEN)))
		    {
		    	fixScale(readcount, buf);
				MinMax_Update(mm, buf, readcount);

				if (++blockcount % 10240 == 0) { putchar('.'); fflush(stdout); }
			}

		    sf_close(infile);
		}
	}
	printf("\r");

	MinMax_dump(fname, mm);

	return 0;
}


//--------------------------------------------------------

PRIVATE FLOAT norm(MINMAX *mm, FLOAT v, FLOAT fudge)
{
	FLOAT min = mm->minf - fudge;
	if (v < min) v = min;
	if (v > mm->maxf) v = mm->maxf;

	return (v - min) * (1.0/(mm->maxf-min));
}


PRIVATE void maxScale(sf_count_t count, FLOAT *buf, MINMAX *minmax, FLOAT fudge)
// Scale so signal is maxed out to 0.0 to 1.0.
{
	int i;
	for (i=0; i<count; ++i)
	{
		*buf = norm(minmax, *buf, fudge);
		++buf;
	}
}

#ifdef DEBUG
PRIVATE void dump_(FLOAT *f)
{
	int i = BUFFER_LEN;

	while (i > 0)
	{
		printf("%d | %f\n", i, *f);
		--i;  ++f;
	}
}
#endif

PRIVATE void process_buffers(sf_count_t count, FLOAT *color_buf, FLOAT *blank_buf, CIRGB *pp)
{
	static FLOAT red_buf  [BUFFER_LEN];
	static FLOAT green_buf[BUFFER_LEN];
	static FLOAT blue_buf [BUFFER_LEN];

	for (int i=0; i<count; ++i)
	{
		FLOAT v = *blank_buf++ + pp->blanking_fudge;
		FLOAT c = *color_buf   + pp->color_fudge;
		FLOAT g= pp->output_gain;
		RGB rgb;

		lookupRGB( *color_buf++, &rgb);

		if (pp->invert_colors)
		{
			red_buf  [i] = 1 - ((rgb.Red   * v) * g);
			green_buf[i] = 1 - ((rgb.Green * v) * g);
			blue_buf [i] = 1 - ((rgb.Blue  * v) * g);
		}
		else
		{
			red_buf  [i] = (rgb.Red   * v) * g;
			green_buf[i] = (rgb.Green * v) * g;
			blue_buf [i] = (rgb.Blue  * v) * g;
		}
	}

	sf_write_double(pp->red_outfile, red_buf, count);
	sf_write_double(pp->green_outfile, green_buf, count);
	sf_write_double(pp->blue_outfile, blue_buf, count);
}


PRIVATE char *build_filename( char *base_dir, char *base_name, char *extention )
{
	size_t len = strlen(base_dir) + strlen(base_name) + strlen(extention) + 10;
	char *buff = malloc(len);

	if (buff)
	{
		sprintf(buff, "%s%s%s", base_dir, base_name, extention);
	}

	return buff;
}


PRIVATE void setup_cirgb(CIRGB *x)
{
	memset(x, 0, sizeof(CIRGB));

	x->palette_fname  = build_filename(cfg.Base_Dir, cfg.Palette_Name, "");
	x->color_fname    = build_filename(cfg.Base_Dir, cfg.Project_Name, "-C.wav");
	x->blanking_fname = build_filename(cfg.Base_Dir, cfg.Project_Name, "-I.wav");
	x->red_fname      = build_filename(cfg.Base_Dir, cfg.Project_Name, "-R.wav");
	x->green_fname    = build_filename(cfg.Base_Dir, cfg.Project_Name, "-G.wav");
	x->blue_fname     = build_filename(cfg.Base_Dir, cfg.Project_Name, "-B.wav");

	sscanf(cfg.Blanking_Fudge, "%lf", &x->blanking_fudge);
	sscanf(cfg.Color_Fudge,    "%lf", &x->color_fudge);
	sscanf(cfg.Output_Gain,    "%lf", &x->output_gain);
	sscanf(cfg.Sample_Offset,   "%d", &x->sample_offset);

	x->invert_colors = (strcmp("True", cfg.Invert_Colors) == 0);
}


PRIVATE void dump_cirgb(CIRGB *x)
{
	printf("pallet '%s'\n", x->palette_fname);
	printf("color '%s'\n", x->color_fname);
	printf("blanking '%s'\n", x->blanking_fname);
	printf("pallet '%s'\n", x->red_fname);
	printf("pallet '%s'\n", x->green_fname);
	printf("pallet '%s'\n", x->blue_fname);
	printf("blanking fudge %f\n", x->blanking_fudge);
	printf("color fudge %f\n", x->color_fudge);
	printf("output gain %f\n", x->output_gain);
	printf("sample offset %d\n", x->sample_offset);
	printf("invert colors %d\n", x->invert_colors);
}


PRIVATE void process_file(CIRGB *x)
{
	int offs = x->sample_offset;
	sf_count_t counter = 0;
	sf_count_t block = 0;
	BOOL running = TRUE;
	static FLOAT color_buf[BUFFER_LEN];
	static FLOAT blank_buf[BUFFER_LEN];

	printf("Creating RGB files....\n");

	if (offs > 0)
	{
		size_t i = offs;
	
		memset(color_buf, 0, sizeof(color_buf));

		while (i > 0)
		{
			size_t s = (i <= BUFFER_LEN) ? i : BUFFER_LEN;
			sf_write_double(x->red_outfile, color_buf, s);
			sf_write_double(x->green_outfile, color_buf, s);
			sf_write_double(x->blue_outfile, color_buf, s);
			i -= s;
		}
	}
	else if (x->sample_offset < 0)
	{
		size_t i = -offs;

		while (i > 0)
		{
			size_t s = (i <= BUFFER_LEN) ? i : BUFFER_LEN;
			sf_read_double(x->color_infile, color_buf, s);
			sf_read_double(x->blank_infile, blank_buf, s);
			i -= s;
		}
	}

	while (running)
	{
		sf_count_t color_readcount = sf_read_double(x->color_infile, color_buf, BUFFER_LEN);
		sf_count_t blank_readcount = sf_read_double(x->blank_infile, blank_buf, BUFFER_LEN);

		if (color_readcount == 0) { break; }

		if (color_readcount == blank_readcount)
		{
			fixScale(color_readcount, color_buf);
			maxScale(color_readcount, color_buf, &x->color_minmax, x->color_fudge);

			fixScale(blank_readcount, blank_buf);
			maxScale(blank_readcount, blank_buf, &x->blanking_minmax, x->blanking_fudge);

			process_buffers( color_readcount, color_buf, blank_buf, x );
		}
		else
		{
			printf("input files are different lengths!\n");
			running = FALSE;
		}

		counter += color_readcount;

		if (++block % 1024 == 0) 
		{
			printf("  %d         \r", x->color_minmax.count - counter);
			fflush(stdout);
		}
	}
	printf("...Finished Creating RGB files\n");
	printf("R[%s]\n", x->red_fname);
	printf("G[%s]\n", x->green_fname);
	printf("B[%s]\n", x->blue_fname);
}

PRIVATE void dumpHtm(CIRGB *x)
{
	char htm[1024];

	sprintf(htm, "%s.html", x->palette_fname);
//	printf("Saving html palette to '%s'\n", Base_FileName(htm));
	dumpHtmlFine( htm, 2000 );
}


PRIVATE BOOL getPalette(CIRGB *x)
{
	char pal[1024];

	sprintf(pal, "%s.txt", x->palette_fname);
//	printf("Reading palette from '%s'\n", Base_FileName(pal));

	if ( readPalette(pal) )
	{
		dumpHtm(x);
		return TRUE;
	}
	return FALSE;
}


PRIVATE int DoIt( CIRGB *x )
{
	if ( MinMax_Read(x->color_fname, &x->color_minmax) == 0)
	{
		if ( MinMax_Read(x->blanking_fname, &x->blanking_minmax) == 0)
		{
			if ( getPalette(x) )
			{
				if ((x->color_infile = sf_open(x->color_fname, SFM_READ, &x->sfinfo)))
				{
					if ((x->blank_infile = sf_open(x->blanking_fname, SFM_READ, &x->sfinfo)))
					{
					    if ((x->red_outfile = sf_open(x->red_fname, SFM_WRITE, &x->sfinfo)))
					    {
						    if ((x->green_outfile = sf_open(x->green_fname, SFM_WRITE, &x->sfinfo)))
						    {
							    if ((x->blue_outfile = sf_open(x->blue_fname, SFM_WRITE, &x->sfinfo)))
							    {
							    	process_file(x);
								    sf_close(x->blue_outfile);
							    }
							    else
							    {   printf("Not able to open blue output file '%s'.\n", x->blue_fname);
							        sf_perror(NULL);
							        return 1;
							    }
							    sf_close(x->green_outfile);
						    }
						    else
						    {   printf("Not able to open green output file '%s'.\n", x->green_fname);
						        sf_perror(NULL);
						        return 1;
						    }
						    sf_close(x->red_outfile);
					    }
					    else
					    {   printf("Not able to open blue output file '%s'.\n", x->blue_fname);
					        sf_perror(NULL);
					        return 1;
					    }
					    sf_close(x->blank_infile);
					}
					else { printf("Can't read blanking file '%s'\n", x->blanking_fname); }

				    sf_close(x->color_infile);
				}
				else { printf("Can't read color file '%s'\n", x->color_fname); }
			}
		}
		else { printf("Can't read min max from '%s'.\n", x->blanking_fname); }
	}
	else { printf("Can't read min max from '%s'.\n", x->color_fname); }

	return 0;
}


int main(int argc, char **argv)
{
	int result = 0;

//printf("argc %d\n", argc);

	if (argc == 2)
	{
		char *cfgname = build_filename("", argv[1], ".cfg");

		if ( read_cirgb_cfg(cfgname) )
		{
			static CIRGB x;

			setup_cirgb(&x);

//			dump_cirgb(&x);

			Zap_MinMax( &x.color_minmax );
			Zap_MinMax( &x.blanking_minmax );

			result = DoIt(&x);
		}
	}
	else { printf("Usage: %s <configname>\nEg: %s test\n\n", Base_FileName(argv[0]), Base_FileName(argv[0])); }

	printf("Press ENTER to Continue.");
	getchar();
	return result;
}


#ifdef COMMENT
void xxx(void)
{
	static CIRGB x;
	Zap_MinMax( &x.blanking_minmax );
	DoIt(&x);
}

PRIVATE void test_scale( SNDFILE *infile, MINMAX *minmax, SNDFILE *outfile, FLOAT fudge )
{
	static FLOAT buf[BUFFER_LEN];
	int readcount;

	while ((readcount = sf_read_double(infile, buf, BUFFER_LEN)))
	{
		fixScale(readcount, buf);
		maxScale(readcount, buf, minmax, fudge);

	 	sf_write_double(outfile, buf, readcount);
	}
}

SNDFILE *outfile;

if ( (outfile = sf_open("OUTB.WAV", SFM_WRITE, &x.sfinfo)))
{
	test_scale( x.blank_infile, &x.blanking_minmax, outfile, -0.1 );

    sf_close(outfile);
}

if ( (outfile = sf_open("OUTC.WAV", SFM_WRITE, &x.sfinfo)))
{
	test_scale( x.color_infile, &x.color_minmax, outfile, 0 );

    sf_close(outfile);
}
#endif



// EndFile: CIRGB.C