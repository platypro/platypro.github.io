/* 
 * Aeden McClain (c) 2016
 * web:   https://www.platypro.net
 * email: dev@platypro.net
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>. 
 */

#define GAME_TYPETOP 7

#define TYPE_PLAYER  0 //Player vector data (or ready)
#define TYPE_PNAME   1 //Player Name Signal
#define TYPE_TEAM    2 //Team Signal
#define TYPE_SCORE   3 //Score Signal
#define TYPE_FLAG    4 //Flag Signal
#define TYPE_STAMINA 5 //Stamina Signal

#define TEAM_FLAGCOUNT 3

#include "General.h"
#include <ServerAPI.h>
#include "Prism-Server.h"
#include "Players.h"

extern bool Game_AddPlayer(SERVERNODE* cnode);

extern void Game_Reset(SERVERSTATE* game);
extern void Game_End(SERVERSTATE* game);

//Items to interface with Player Module
extern int  Game_Get(char header, char* request, void* data, struct PlayerContext* context);
extern char Game_Put(char* string, int maxlen, int signal, void* user, int playerID, bool myself);
extern int Game_Update(void* userdata, int tick, struct PlayerContext* context);

extern char Game_PutStatic(char* string, int maxlen, void* data, int objtype, void* user);
