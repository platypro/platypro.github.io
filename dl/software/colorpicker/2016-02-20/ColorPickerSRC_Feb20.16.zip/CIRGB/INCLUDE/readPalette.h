
#ifndef READPALETTE_H
#define READPALETTE_H

#define MAX_PALETTE_S 100
#define MAX_VAL_S 255

#define FTABLE_SIZE 100

typedef struct 
{
	FLOAT Red;
	FLOAT Green;
	FLOAT Blue;

} RGB;

BOOL readPalette( char *fname );
void scaleRGB( RGB *dest, FLOAT scale );
void setRGB( RGB *dest, RGB *source );
void interpRGB( RGB *dest, RGB *sourceL, RGB *sourceH, FLOAT f );
void lookupRGB(FLOAT f, RGB *rgb);
void dumpTable( char *fname );
void dumpTable2( char *fname );
void dumpHtml( char *fname );
void dumpTableFine( char *fname, int steps );
void dumpHtmlFine( char *fname, int steps );

#endif  // READPALETTE_H
